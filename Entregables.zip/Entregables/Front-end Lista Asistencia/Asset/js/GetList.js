
function loadModules() {
  $.ajax({
    url: 'http://localhost:9000/api/seguridad/modulos',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione Modulo --</option>`;
      items.forEach(function (modulos, index, array) {
        registros += `<option value='` + modulos.id + `'>` + modulos.codigo + ' - ' + modulos.etiqueta + ' - ' + modulos.ruta + `</option>`;
      })
      $("#modulosId").html(registros);
    }
  });
}

function loadUsuario() 
  $.ajax({
    url: 'http://localhost:9000/api/seguridad/usuarios',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione Usuario --</option>`;
      items.forEach(function (usuarios, index, array) {
        var nombreCompleto = usuarios.primerNombre + " " + usuarios.segundoNombre + " " + usuarios.apellido + " " + usuarios.segundoApellido;
        registros += `<option value='` + usuarios.id + `'>` + nombreCompleto + `</option>`;
      })
      $("#usuariosId").html(registros);
    }
  });

  


function loadVistaRoles() {
  $.ajax({
    url: 'http://localhost:9000api/seguridad/vistas',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione Vista --</option>`;
      items.forEach(function (vistas, index, array) {
        registros += `<option value='` + vistas.id + `'>` + vistas.ruta + " - " + vistas.etiqueta + `</option>`;
      })
      $("#vistasId").html(registros);
    }
  });

  $.ajax({
    url: 'http://localhost:9000/api/seguridad/roles',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione Rol --</option>`;
      items.forEach(function (roles, index, array) {
        registros += `<option value='` + roles.id + `'>` + roles.codigo + ' - ' + roles.descripcion +`</option>`;
      })
      $("#rolesId").html(registros);
    }
  });
}

function loadAsistencia() {
  $.ajax({
    url: 'http://localhost:9000/api/listaAsistencia/asistencia',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione Vista --</option>`;
      items.forEach(function (asistencia, index, array) {
        
        registros += `<option value='` + asistencia.id + `'>` + asistencia.materiasId.nombreMateria +
         " - " + asistencia.materiasId.descripcion + " - " + asistencia.materiasId.horario +" - " + asistencia.usuarioId.primerNombre +
         " - " + asistencia.usuarioId.segundoNombre +" - " + asistencia.usuarioId.apellido +" - " + asistencia.fechaInscripcion+`</option>`;
      })
      $("#asistenciaId").html(registros);
    }
  })
}

function loadCursos() {
  $.ajax({
    url: 'http://localhost:9000/api/listaAsistencia/cursos',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione factura --</option>`;
      items.forEach(function (cursos, index, array) {
        registros += `<option value='` + cursos.id + `'>` + asistencia.materiasId.nombreMateria +
        " - " + asistencia.materiasId.descripcion + " - " + asistencia.materiasId.horario +
        " - "  + asistencia.usuarioId.primerNombre +  " - " + asistencia.usuarioId.segundoNombre +
        " - " + asistencia.usuarioId.apellido +" - "+ cursos.horaInicio + " - " + cursos.horaFin + `</option>`;
      })
      $("#cursosId").html(registros);
    }
  })
}

function loadMaterias() {
  $.ajax({
    url: 'http://localhost:9000/api/listaAsistencia/materias',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione factura --</option>`;
      items.forEach(function (materias, index , array) {
          registros += `<option value='` + materias.id + `'>` + materias.nombreMateria + 
          " - " + materias.descripcion + " - " + materias.horario + `</option>`;
      })
      $("#materiasId").html(registros);
    }
  })
}


function loadUsuarioRoles() {
  
  $.ajax({
    url: 'http://localhost:9000/api/seguridad/usuarios',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione Usuario --</option>`;
      items.forEach(function (usuarios, index, array) {
        registros += `<option value='` + usuarios.id + `'>` + usuarios.usuarios +' - '+usuarios.contraseña+ ' - '+usuarios.tipoUsuario+`</option>`;
      })
      $("#usuariosId").html(registros);
    }
  });

  $.ajax({
    url: 'http://localhost:9000/api/seguridad/roles',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      var registros = `<option selected='' selected disabled hidden value='0'>-- Seleccione Rol --</option>`;
      items.forEach(function (roles, index, array) {
        registros += `<option value='` + roles.id + `'>` + roles.codigo + ' - ' + roles.descripcion +`</option>`;
      })
      $("#rolesId").html(registros);
    }
  });
}