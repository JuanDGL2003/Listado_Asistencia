// Consultar modulos
function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/modulos',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (modulos, index, array) {
                registros += `
                            <tr class="table-light">
                                <td>`+ modulos.id + `</td>
                                <td>`+ modulos.codigo +`</td>
                                <td>`+ modulos.etiqueta + `</td>
                                <td>`+ modulos.ruta + `</td>
                                <td class="`+ (module.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + modulos.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+modulos.id+`); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+modulos.id+`);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la modulos por su ID
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/modulos' + id,
            type: 'GET',
            dataType: 'json',
            success: function (modulos) {
                // Rellenar los campos del formulario con la información de la modulos
                $('#id').val(modulos.id);
                $('#codigo').val(modulos.codigo);
                $('#label').val(modulos.etiqueta);
                $('#router').val(modulos.ruta);
                $('#estado').val(modulos.state);
                Swal.fire({
                    title: "Modulo encontrado",
                    icon: "success"
                });
            
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "Modulo no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}

function agregarModulo(){
    // Validar los campos del formulario
    if (!validarCampos()) {
        return; // Si hay campos inválidos, salir de la función
    }
    
    // Crea un objeto con los datos del formulario
    var formData = {
        codigo: $('#codigo').val(),
        etiqueta: $('#etiqueta').val(),
        ruta: $('#ruta').val(),
        state: $('#estado').val()
        // Agrega otros campos aquí
    };
    // Envía la solicitud POST a la API utilizando AJAX
    $.ajax({
        type: 'POST',
        url: 'http://localhost:9000/api/seguridad/modulos',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function () {
            Swal.fire({
                title: "Modulo registrada",
                icon: "success"
            });
            loadTable();
            Limpiar();
        },
        error: function () {
            Swal.fire({
                title: "Ha ocurrido un error al registrar el modulo",
                icon: "error"
            });
        }
    });
}

// Guardar cambios modulos.

function guardarCambios() {
    $(document).ready(function () {
        // Obtener el ID de la persona a actualizar
        var id = $('#id').val();

        // Crear un objeto con los datos del formulario
        var formData = {
            codigo: $('#codigo').val(),
            etiqueta: $('#etiqueta').val(),
            ruta: $('#ruta').val(),
            state: $('#estado').val()
        };

        // Realizar una petición Ajax para actualizar la información del Modulo
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/modulos' + id,
            type: 'Put',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Modulo actualizada",
                    icon: "success"
                });
                loadTable();        
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar el modulo",
                    icon: "error"
                });
            }
        });
    });
}


//Accion para eliminar un registro seleccionado 

function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/modulos' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function(result) {
            Swal.fire({
                title: "Modulo Eliminado",
                icon: "success"
            });
            loadTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}


function Limpiar(){
    // Agrega este código al final de la función 'success' de la petición Ajax para actualizar la persona
    // Limpia los valores de todos los campos del formulario
    $('#codigo').val('');
    $('#etiqueta').val('');
    $('#ruta').val('');
    $('#estado').val('0');
    $('#usuarioCreacion').val('');
    $('#usuarioModificacion').val('');
    $('#fechaCreacion').val('');
    $('#fechaModificacion').val('');
}

// Validar Campos

function validarCampos() {
    var codigo = $('#codigo').val();
    var descripcion = $('#descripcion').val();
    var estado = $('#estado').val();
    var usuarioCreacion = $('#usuarioCreacion').val();
    var usuarioModificacion = $('#usuarioModificacion').val();
    var fechaCreacion = $('#fechaCreacion').val();
    var fechaModificacion = $('#fechaModificacion').val();
    
    if (codigo == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Código es requerido',
            icon: 'error'
        });
        return false;
    }
    
    if (descripcion == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Descripción es requerido',
            icon: 'error'
        });
        return false;
    }
    
    if (estado == '0') {
        Swal.fire({
            title: 'Error',
            text: 'Debe seleccionar un Estado',
            icon: 'error'
        });
        return false;
    }
    
    if (usuarioCreacion == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Usuario Creación es requerido',
            icon: 'error'
        });
        return false;
    }
    
    if (usuarioModificacion == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Usuario Modificación es requerido',
            icon: 'error'
        });
        return false;
    }
    
    if (fechaCreacion == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Fecha Creación es requerido',
            icon: 'error'
        });
        return false;
    }
    
    if (fechaModificacion == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Fecha Modificación es requerido',
            icon: 'error'
        });
        return false;
    }
    
    return true;
}