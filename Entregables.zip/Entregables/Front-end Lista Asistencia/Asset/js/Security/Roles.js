// Carga la tabla.
function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/roles',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (roles, index, array) {
                registros += `
                            <tr class="table-light">
                                <td>`+ roles.id + `</td>
                                <td>`+ roles.codigo +`</td>
                                <td>`+ roles.descripcion + `</td>
                                <td class="`+ (roles.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + roles.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+roles.id+`); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+roles.id+`);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información del Rol por su ID
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/roles/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (roles) {
                // Rellenar los campos del formulario con la información del Rol
                $('#id').val(roles.id);
                $('#codigo').val(roles.codigo);
                $('#descripcion').val(roles.descripcion);
                $('#estado').val(roles.state);
                Swal.fire({
                    title: "Rol encontrada",
                    icon: "success"
                });
            
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "Rol no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}

// Registrar Roles
function agregarRol(){
        if (!validarCampos()) {
            return; // Si hay campos inválidos, salir de la función
        }
        // Crea un objeto con los datos del formulario
         var formData = {
            codigo: $('#codigo').val(),
            descripcion: $('#descripcion').val(),
            state: $('#state').val()
        };
         // Envía la solicitud POST a la API utilizando AJAX
        $.ajax({
            type: 'POST',
            url: 'http://localhost:9000/api/seguridad/roles',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Rol resgistrado",
                    icon: "success"
                });
                loadTable();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                title: "Ha ocurrido un error al registrar el rol",
                icon: "error"
            });
        }
    });
}


function guardarCambios() {
    $(document).ready(function () {
        // Obtener el ID del Rol a actualizar
        var id = $('#id').val();

        // Crear un objeto con los datos del formulario
        var formData = {
            codigo: $('#codigo').val(),
            descripcion: $('#descripcion').val(),
            state: $('#estado').val()
        };

        // Realizar una petición Ajax para actualizar la información de la persona
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/roles/' + id,
            type: 'PUT',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Rol actualizada",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar el rol",
                    icon: "error"
                });
            }
        });
    });
}


//Accion para eliminar un registro seleccionado 
function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/roles/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function(result) {
            Swal.fire({
                title: "Rol Eliminado",
                icon: "success"
            });
            loadTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}


function Limpiar(){
    // Agrega este código al final de la función 'success' de la petición Ajax para actualizar la persona
    // Limpia los valores de todos los campos del formulario
    $('#codigo').val('');
    $('#descripcion').val('');
    $('#estado').val('0');
}


function validarCampos() {
    var codigo = $('#codigo').val();
    var descripcion = $('#descripcion').val();
    var estado = $('#estado').val();
    
    if (codigo == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Código es requerido',
            icon: 'error'
        });
        return false;
    }
    
    if (descripcion == '') {
        Swal.fire({
            title: 'Error',
            text: 'El campo Descripción es requerido',
            icon: 'error'
        });
        return false;
    }
    
    if (estado == '0') {
        Swal.fire({
            title: 'Error',
            text: 'Debe seleccionar un Estado',
            icon: 'error'
        });
        return false;
    }
    
    return true;
}