function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/vistas',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (vistas, index, array) {
                registros += `
                            <tr class="table-light">
                                <td>`+vistas.id+`</td>                            
                                <td>`+vistas.modulosId.codigo+' - '+vistas.modulosId.ruta+`</td>          
                                <td>`+vistas.codigo+`</td>
                                <td>`+vistas.ruta+`</td>
                                <td  style="text-align: center;"><i class="`+vistas.icono+`"></i></td>
                                <td>`+vistas.etiqueta+`</td>
                                <td class="`+ (vistas.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + vistas.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+vistas.id+`); bloquearBotonEnvio();"  data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+vistas.id+`);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);   
        },
        error: function(xhr, status, error) {
            console.log("Ha ocurrido un error: " + error);
        }
    });
}

function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la persona por su ID
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/vistas/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (vistas) {
                // Rellenar los campos del formulario con la información de la persona
                $('#id').val(vistas.id);
                $('#moduloId').val(vistas.modulosId.id);
                $('#codigo').val(vistas.codigo);
                $('#ruta').val(vistas.ruta);
                $('#etiqueta').val(vistas.etiqueta);
                $('#icon').val(vistas.icono);
                $('#estado').val(vistas.state);
                Swal.fire({
                    title: "Vista encontrada",
                    icon: "success"
                });
            
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "Vista no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}


// Registrar Vista
function agregarVista() {
    if (validarCampos()) {
        // Crea un objeto con los datos del formulario
        var formData = {
            modulosId: {
                id : $("#modulosId").val()
              },
            codigo: $('#codigo').val(),
            ruta: $('#ruta').val(),
            etiqueta: $('#etiqueta').val(),
            icono: $('#icono').val(),
            state: $('#estado').val()
        };
        
        // Envía la solicitud POST a la API utilizando AJAX
        $.ajax({
            type: 'POST',
            url: 'http://localhost:9000/api/seguridad/vistas',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: 'Vista registrada',
                    icon: 'success'
                });
                loadTable();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: 'Ha ocurrido un error al registrar la vista',
                    icon: 'error'
                });
            }
        });
    }
}


// Update informacion views
function guardarCambios() {
    $(document).ready(function () {
        // Obtener el ID de la persona a actualizar
        var id = $('#id').val();

        // Crear un objeto con los datos del formulario
        var formData = {
            modulosId: {
                id : $("#modulosId").val()
              },
              codigo: $('#codigo').val(), 
              ruta: $('#ruta').val(),
              etiqueta: $('#etiqueta').val(),
              icono: $('#icono').val(),   
              state: $('#estado').val()
        };

        $.ajax({
            url: 'http://localhost:9000/api/seguridad/vistas/' + id,
            type: 'PUT',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Vista actualizada",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar la vista",
                    icon: "error"
                });
            }
        });
    });
}


//Accion para eliminar un registro seleccionado 
function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/vistas/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function(result) {
            Swal.fire({
                title: "Vista eliminada",
                icon: "success"
            });
            loadTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}

function Limpiar(){
    // Limpia los valores de todos los campos del formulario
    $('#ruta').val('');
    $('#etiqueta').val('');
    $('#codigo').val('');
    $('#icono').val('');
    $('#estado').val('0');
    $('#modulosId').val('0');
}

// Validar campos

function validarCampos() {
    var ruta = $('#ruta').val();
    var etiqueta = $('#etiqueta').val();
    var icono = $('#icono').val();
    var estado = $('#estado').val();
    var moduloId = $('#moduloId').val();

    if (ruta === '' || etiqueta === '' || estado === '0' || moduloId === '0' || icono === '') {
        Swal.fire({
            title: "Error",
            text: "Por favor, complete todos los campos del formulario.",
            icon: "error"
        });
        return false;
    }
    return true;
}