// Carga Tabla de Usuario Roles
function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/usuarios_roles',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (UsuariosRoles, index, array) {
                registros += `
                            <tr class="table-light">
                                <td>`+UsuariosRoles.id+`</td>                            
                                <td>`+UsuariosRoles.usuariosId.usuarios+`</td>                            
                                <td>`+UsuariosRoles.rolesId.descripcion+`</td>
                                <td class="`+ (UsuariosRoles.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + UsuariosRoles.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+UsuariosRoles.id+`); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+UsuariosRoles.id+`);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function(xhr, status, error) {
            console.log("Ha ocurrido un error: " + error);
        }
    });
}

// Buscar Usuario rol con id
function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la persona por su ID
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/usuarios_roles/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (UsuariosRoles) {
                // Rellenar los campos del formulario con la información de la persona
                $('#id').val(UsuariosRoles.id);
                $('#usuariosId').val(UsuariosRoles.usuariosId.id);
                $('#rolesId').val(UsuariosRoles.rolesId.id);
                $('#estado').val(UsuariosRoles.state);
                Swal.fire({
                    title: "Usuario con el rol enctrado",
                    icon: "success"
                });
            
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "Usuario con el rol no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}

//Registrar Usuario
function agregarUsuarioRoles() {
    // Valida los campos del formulario antes de hacer la petición AJAX
    if (!validarCampos()) {
        return;
    }

    // Crea un objeto con los datos del formulario
    var formData = {
        rolesId: {
            id: $("#rolesId").val()
        },
        usuariosId: {
            id: $("#usuariosId").val()
        },
        state: $('#estado').val()
    };
    // Envía la solicitud POST a la API utilizando AJAX
    $.ajax({
        type: 'POST',
        url: 'http://localhost:9000/api/seguridad/usuarios_roles',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function () {
            Swal.fire({
                title: "Rol Usuario registrado",
                icon: "success"
            });
            loadTable();
            Limpiar();
        },
        error: function () {
            Swal.fire({
                title: "Ha ocurrido un error al registrar el Rol Usuario",
                icon: "error"
            });
        }
    });
}



function guardarCambios() {
    $(document).ready(function () {
        // Obtener el ID de la persona a actualizar
        var id = $('#id').val();

        // Crear un objeto con los datos del formulario
        var formData = {
            rolesId: {
                id: $("#rolesId").val()
            },
            usuariosId: {
                id: $("#usuariosId").val()
            },
            state: $('#estado').val()
        };
        // Realizar una petición Ajax para actualizar la información de la persona
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/usuarios_roles/' + id,
            type: 'PUT',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Usuario con rol actualizada",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar al usuario con rol.",
                    icon: "error"
                });
            }
        });
    });
}

//Accion para eliminar un registro seleccionado 
function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/usuarios_roles/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function(result) {
            Swal.fire({
                title: "Usuario Eliminado",
                icon: "success"
            });
            loadTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}

// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}

function Limpiar(){
    // Limpia los valores de todos los campos del formulario
    $('#rolesId').val('0');
    $('#usuariosId').val('0');
    $('#estado').val('0');
}

// Valida los campos

function validarCampos() {
    var rolesId = $('#rolesId').val();
    var usuariosId = $('#usuariosId').val();
    var estado = $('#estado').val();

    // Verifica que los campos obligatorios no estén vacíos
    if (rolesId == '0') {
        Swal.fire({
            title: "Error",
            text: "Debe seleccionar un Rol",
            icon: "error",
        });
        return false;
    }

    if (usuariosId == '0') {
        Swal.fire({
            title: "Error",
            text: "Debe seleccionar un Usuario",
            icon: "error",
        });
        return false;
    }

    if (estado == '0') {
        Swal.fire({
            title: "Error",
            text: "Debe seleccionar un Estado",
            icon: "error",
        });
        return false;
    }

    return true;
}