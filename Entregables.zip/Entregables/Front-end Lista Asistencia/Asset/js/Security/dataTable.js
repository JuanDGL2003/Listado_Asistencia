// dataTable
$(document).ready( function () {
    $('#tabla').DataTable();
} );