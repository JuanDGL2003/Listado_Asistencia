function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/usuarios',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (usuarios, index, array) {
                var contraseña = usuarios.contraseña;
                var asterisks = '';
                for (var i = 0; i < contraseña.length; i++) {
                asterisks += '*';
                }
                var contraseñaMasked = asterisks;
                registros += `
                            <tr class="table-light">
                                <td>`+usuarios.id+`</td>                            
                                <td>`+usuarios.primerNombre+' '+usuarios.segundoNombre+' '+usuarios.apellido+' '+usuarios.segundoApellido+`</td>                            
                                <td>`+usuarios.tipoUsuario+`</td>
                                <td>`+usuarios.usuarios+`</td>
                                <td>`+ contraseñaMasked +`</td>
                                <td class="`+ (usuarios.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + usuarios.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+usuarios.id+`); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+usuarios.id+`);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function(xhr, status, error) {
            console.log("Ha ocurrido un error: " + error);
        }
    });
}

// Buscar usuario por Id

function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la persona por su ID
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/usuarios/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (usuarios) {
                // Rellenar los campos del formulario con la información del usuario
                $('#id').val(usuarios.id);
                $('#usuario').val(usuarios.usuarios);
                $('#contraseña').val(usuarios.contraseña);
                $('#tipoUsuario').val(tipoUsuario),
                $('#estado').val(usuarios.state);
                Swal.fire({
                    title: "Usuario encontrada",
                    icon: "success"
                });
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "Usuario no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}


// Registrar Usuario
function agregarUsuario() {
    if(!validarCampos()) {
        return;
    }

    // Crea un objeto con los datos del formulario
    var formData = {
        id:$('#id').val(),
        usuarios: $('#usuarios').val(),
        contraseña: $('#contraseña').val(),
        tipoUsuario: $('#tipoUsuario').val(),
        state: $('#estado').val()
    };

    // Envía la solicitud POST a la API utilizando AJAX
    $.ajax({
        type: 'POST',
        url: 'http://localhost:9000/api/seguridad/usuarios',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function () {
            Swal.fire({
                title: "Usuario registrado",
                icon: "success"
            });
            loadTable();
            Limpiar();
        },
        error: function () {
            Swal.fire({
                title: "Ha ocurrido un error al registrar el usuario",
                icon: "error"
            });
        }
    });
}



function guardarCambios() {
    $(document).ready(function () {
        // Obtener el ID de la persona a actualizar
        var id = $('#id').val();

        // Crear un objeto con los datos del formulario
        var formData = {
            id: $('#id').val(),
            usuarios: $('#usuarios').val(),
            constraseña: $('#constraseña').val(),
            state: $('#estado').val()
        };

        // Realizar una petición Ajax para actualizar la información de la persona
        $.ajax({
            url: 'http://localhost:9000/api/seguridad/usuarios/' + id,
            type: 'PUT',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Usuario actualizada",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar el usuario",
                    icon: "error"
                });
            }
        });
    });
}

//Accion para eliminar un registro seleccionado 
function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/seguridad/usuarios/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function(result) {
            Swal.fire({
                title: "Usuario Eliminado",
                icon: "success"
            });
            loadTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Poder observar Contraseña.
$(document).ready(function() {
    $('#toggle-constraseña').click(function() {
      var constraseñaField = $('#constraseña');
      var constraseñaFieldType = constraseñaField.attr('type');
      if (constraseñaFieldType === 'constraseña') {
        constraseñaField.attr('type', 'text');
        $(this).html('<i class="far fa-eye-slash"></i>');
      } else {
        constraseñaField.attr('type', 'constraseña');
        $(this).html('<i class="far fa-eye"></i>');
      }
    });
});
  

// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}


function Limpiar(){
    // Limpia los valores de todos los campos del formulario
    $('#id').val('0');
    $('#usuarios').val('');
    $('#constraseña').val('');
    $('#tipoUsuario').val('');
    $('#estado').val('0');
}

// Validar Campos

function validarCampos() {
    var id = $('#id').val();
    var tipoUsuario= $('#tipoUsuario').val();
    var usuarios = $('#usuarios').val();
    var constraseña = $('#constraseña').val();
    var estado = $('#estado').val();

    
    if(id == '') {
        Swal.fire({
            title: "Error",
            text: 'El campo "Id" es obligatorio',
            icon: "error"
        });
        return false;
    }

    if(usuarios == '') {
        Swal.fire({
            title: "Error",
            text: 'El campo "Usuario" es obligatorio',
            icon: "error"
        });
        return false;
    }

    if( tipoUsuario== '') {
        Swal.fire({
            title: "Error",
            text: 'El campo "tipoUsuario" es obligatorio',
            icon: "error"
        });
        return false;
    }
    
    if(constraseña == '') {
        Swal.fire({
            title: "Error",
            text: 'El campo "Contraseña" es obligatorio',
            icon: "error"
        });
        return false;
    }
    
    if(estado == '0') {
        Swal.fire({
            title: "Error",
            text: "Debe seleccionar un estado",
            icon: "error"
        });
        return false;
    }

    return true;
}