// Carga Tabla de Usuario Roles
function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/securidad/vistas_roles',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (VistasRoles, index, array) {
                registros += `
                            <tr class="table-light">
                                <td>`+VistasRoles.id+`</td>                            
                                <td>`+VistasRoles.vistasId.etiqueta+`</td>                            
                                <td>`+VistasRoles.rolesId.descripcion+`</td>
                                <td class="`+ (VistasRoles.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + VistasRoles.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+VistasRoles.id+`); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+VistasRoles.id+`);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function(xhr, status, error) {
            console.log("Ha ocurrido un error: " + error);
        }
    });
}

// Buscar Usuario rol con id
function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la persona por su ID
        $.ajax({
            url: 'http://localhost:9000/api/securidad/vistas_roles/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (VistasRoles) {
                // Rellenar los campos del formulario con la información de la persona
                $('#id').val(VistasRoles.id);
                $('#vistaId').val(VistasRoles.vistasId.id);
                $('#rolesId').val(VistasRoles.rolesId.id);
                $('#estado').val(VistasRoles.state);
                Swal.fire({
                    title: "Vista con el rol encontrado",
                    icon: "success"
                });
            
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "Vista con el rol no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}

//Registrar Usuario
function agregarVistaRole() {
    // Validar campos
    if (!validarCampos()) {
        return;
    }

    // Realizar una petición Ajax para crear un nuevo usuario
    $.ajax({
        url: 'http://localhost:9000/api/securidad/vistas_roles',
        type: 'POST',
        dataType: 'json',
        headers: {
            "Content-Type": "application/json"
        },
        data: JSON.stringify({
            rolesId: {
                id: $("#rolesId").val()
            },
            vistasId: {
                id: $("#vistasId").val()
            },
            state: $('#estado').val()
        }),

        success: function (users) {
            // Mostrar mensaje de éxito
            Swal.fire({
                title: "Vista con rol creado exitosamente",
                icon: "success"
            });
            loadTable();
            Limpiar();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            // Mostrar mensaje de error
            Swal.fire({
                title: "Error al crear Vista con rol",
                text: "Por favor revise los datos ingresados e intente de nuevo.",
                icon: "error"
            });
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Guarda Cambios de vista con roles
function guardarCambios() {
    $(document).ready(function () {
        // Obtener el ID de la persona a actualizar
        var id = $('#id').val();

        // Crear un objeto con los datos del formulario
        var formData = {
            rolesId: {
                id: $("#rolesId").val()
            },
            vistasId: {
                id: $("#vistasId").val()
            },
            state: $('#estado').val()
        };
        // Realizar una petición Ajax para actualizar la información de Vista Rol
        $.ajax({
            url: 'http://localhost:9000/api/securidad/vistas_roles/' + id,
            type: 'PUT',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Usuario con rol actualizada",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar al usuario con rol.",
                    icon: "error"
                });
            }
        });
    });
}

//Accion para eliminar un registro seleccionado 
function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/securidad/vistas_roles/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function(result) {
            Swal.fire({
                title: "Usuario Eliminado",
                icon: "success"
            });
            loadTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}

function Limpiar(){
    // Limpia los valores de todos los campos del formulario
    $('#rolesId').val('0');
    $('#vistasId').val('0');
    $('#estado').val('0');
}

// Validar Campos
function validarCampos() {
    // Valida que el campo rolesId esté seleccionado
    var rolesId = $('#rolesId').val();
    if (rolesId === '0') {
        Swal.fire({
            title: 'Error',
            text: 'Debe seleccionar un valor para el campo Rol.',
            icon: 'error'
        });
        return false;
    }
    
    // Valida que el campo vistaId esté seleccionado
    var vistasId = $('#vistasId').val();
    if (vistasId === '0') {
        Swal.fire({
            title: 'Error',
            text: 'Debe seleccionar un valor para el campo Vista.',
            icon: 'error'
        });
        return false;
    }
    
    // Valida que el campo estado esté seleccionado
    var estado = $('#estado').val();
    if (estado === '0') {
        Swal.fire({
            title: 'Error',
            text: 'Debe seleccionar un valor para el campo Estado.',
            icon: 'error'
        });
        return false;
    }
    
    return true;
}

// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}