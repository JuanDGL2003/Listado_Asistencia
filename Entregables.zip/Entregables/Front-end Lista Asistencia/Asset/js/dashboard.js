$(document).ready(function() {

    // Capturar los clics en los enlaces del panel de control
    $("#sidemenu a").click(function(e) {
        e.preventDefault();

        // Obtener la URL del enlace clicado
        var url = $(this).attr("href");

        // Cargar la vista en el iframe
        $("#content-frame").attr("src", url);
    });

    // Cargar index.html en el iframe al iniciar sesión
    $("#content-frame").attr("src", "security/index.html");
});

// Menu dashboard

const btn = document.querySelector('#menu-btn');
const menu = document.querySelector('#sidemenu');

btn.addEventListener('click', e => {
    menu.classList.toggle("menu-expanded");
    menu.classList.toggle("menu-collapsed");
    document.querySelector('body').classList.toggle('body-expanded');
});