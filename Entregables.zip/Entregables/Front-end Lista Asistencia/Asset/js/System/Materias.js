// Consultar facturas
function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/listaAsistencia/materias',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (materias, index, array) {
                registros += `
                            <tr class="table-light">
                                <td style="width: 16px;">`+ materias.id + `</td>
                                <td style="width: 16px;">`+ materias.nombreMateria + `</td>
                                <td style="width: 16px;">`+ materias.descripcion + `</td>
                                <td style="width: 16px;">`+ materias.horario + `</td>
                                <td style="width: 16px;" class="`+ (materias.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + materias.state + `</td>
                                <td style="width: 16px;">
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+ materias.id + `); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+ materias.id + `);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la modulos por su ID
        $.ajax({
            url: 'http://localhost:9000/api/listaAsistencia/materias/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (materias) {
                // Rellenar los campos del formulario con la información de la modulos
                $('#id').val(materias.id);
                $('#nombreMateria').val(materias.nombreMateria);
                $('#descripcion').val(materias.descripcion);
                $('#horario').val(materias.horario);
                $('#state').val(materias.state);
                Swal.fire({
                    title: "Materia encontrada",
                    icon: "success"
                });
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "Materia no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}

function agragarmaterias() {

    var formData = {
        nombreMateria: $('#nombreMateria').val(),
        descripcion: $('#descripcion').val(),
        horario: $('#horario').val(),
        state: $('#state').val()
    };

    $.ajax({
        type: 'POST',
        url: 'http://localhost:9000/api/listaAsistencia/materias',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function () {
            Swal.fire({
                title: "Materia registrada",
                icon: "success"
            });
            loadTable();
            Limpiar();
        },
        error: function () {
            Swal.fire({
                title: "Ha ocurrido un error al registrar el Materia",
                icon: "error"
            });
        }
    });
}

// Guardar cambios modulos.

function guardarCambios() {
    $(document).ready(function () {

        var id = $('#id').val();

        var formData = {
            nombreMateria: $('#nombreMateria').val(),
            descripcion: $('#descripcion').val(),
            horario: $('#horario').val(),
            state: $('#state').val()
        };

        $.ajax({
            url: 'http://localhost:9000/api/listaAsistencia/materias/' + id,
            type: 'Put',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "Materia actualizada",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar Materia",
                    icon: "error"
                });
            }
        });
    });
}


//Accion para eliminar un registro seleccionado 

function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/listaAsistencia/materias/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (result) {
            Swal.fire({
                title: "Materia Eliminada",
                icon: "success"
            });
            loadTable();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}


function Limpiar() {
    $('#nombreMateria').val('');
    $('#descripcion').val('');
    $('#horario').val('');
    $('#state').val('0');
}