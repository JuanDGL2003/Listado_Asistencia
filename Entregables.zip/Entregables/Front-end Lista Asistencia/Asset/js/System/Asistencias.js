// Consultar detalleFacturas
function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/listaAsistencia/asistencia',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (asistencia, index, array) {
                registros += `
                            <tr class="table-light">
                                <td>`+ asistencia.id + `</td>
                                <td style="text-align: center;">`+ asistencia.materiasId.nombreMateria + " - " + asistencia.materiasId.descripcion + " - " + asistencia.materiasId.horario+`</td>
                                <td>`+ asistencia.usuarioId.primerNombre + " - "+ asistencia.usuarioId.segundoNombre+" - "+ asistencia.usuarioId.apellido + `</td>
                                <td>`+ asistencia.fechaInscripcion+`</td>
                                <td class="`+ (asistencia.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + asistencia.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+asistencia.id+`); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+asistencia.id+`);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la modulos por su ID
        $.ajax({
            url: 'http://localhost:9000/api/listaAsistencia/asistencia/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (detalleFactura) {
                // Rellenar los campos del formulario con la información de la modulos
                $('#id').val(asistencia.id);
                $('#materiasId').val(asistencia.materiasId.id);
                $('#usuarioId').val(asistencia.usuarioId.id);
                $('#fechaInscripcion').val(asistencia.fechaInscripcion);
                $('#state').val(asistencia.state);
                Swal.fire({
                    title: "asistencia encontrada",
                    icon: "success"
                });
                habilitarBotonGuardar();

            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "asistencia no encontrada",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}

function agragarAsistencia(){
    
    // Crea un objeto con los datos del formulario
    var formData = {
            materiasId: {
                id: $('#materiasId').val()
            },
            usuarioId: {
                id: $('#usuarioId').val()
            },
            fechaInscripcion: $('#fechaInscripcion').val(),
            state: $('#state').val(),
       
        // Agrega otros campos aquí
    };
    // Envía la solicitud POST a la API utilizando AJAX
    $.ajax({
        type: 'POST',
        url: 'http://localhost:9000/api/listaAsistencia/asistencia',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function () {
            Swal.fire({
                title: "asistencia registrada",
                icon: "success"
            });
            loadTable();
            Limpiar();
        },
        error: function () {
            Swal.fire({
                title: "Ha ocurrido un error al registrar el asistencia",
                icon: "error"
            });
        }
    });
}

// Guardar cambios modulos.

function guardarCambios() {
    $(document).ready(function () {
        // Obtener el ID de la persona a actualizar
        var id = $('#id').val();

        // Crear un objeto con los datos del formulario
        var formData = {
            materiasId: {
                id: $('#materiasId').val()
            },
            usuarioId: {
                id: $('#usuarioId').val()
            },
            fechaInscripcion: $('#fechaInscripcion').val(),
            state: $('#state').val(),
        };

        // Realizar una petición Ajax para actualizar la información de la persona
        $.ajax({
            url: 'http://localhost:9000/api/listaAsistencia/asistencia/' + id,
            type: 'Put',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "asistencia actualizada",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar asistencia",
                    icon: "error"
                });
            }
        });
    });
}


//Accion para eliminar un registro seleccionado 

function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/listaAsistencia/asistencia/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function(result) {
            Swal.fire({
                title: "asistencia Eliminada",
                icon: "success"
            });
            loadTable();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}


function Limpiar(){
    // Agrega este código al final de la función 'success' de la petición Ajax para actualizar la persona
    // Limpia los valores de todos los campos del formulario
    $('#materiasId').val('');
    $('#usuarioId').val('');
    $('#fechaInscripcion').val('');
    $('#state').val('0');
}