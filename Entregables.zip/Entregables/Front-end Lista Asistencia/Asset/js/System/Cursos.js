// Consultar facturas
function loadTable() {
    $.ajax({
        url: 'http://localhost:9000/api/listaAsistencia/cursos',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (items) {
            var registros = "";
            items.forEach(function (cursos, index, array) {
                registros += `
                            <tr class="table-light">
                                <td>`+ cursos.id + `</td>
                                <td>Nombre de los cursos: `+ cursos.nombreCurso + `</td>
                                <td>`+ cursos.materiasId.nombreMateria + " - " + cursos.materiasId.descripcion + " " + cursos.materiasId.horario +`</td>
                                <td>`+ cursos.usuariosId.primerNombre + " - " + cursos.usuariosId.segundoNombre + " " + cursos.usuariosId.apellido +`</td>
                                <td>Hora de inicio: `+ cursos.horaInicio + `</td>
                                <td>Hora Fin: `+ cursos.horaFin + `</td>
                                <td class="`+ (cursos.state === 'Activo' ? 'text-success' : 'text-danger') + `">` + cursos.state + `</td>
                                <td>
                                    <button type="button" class="btn btn-warning me-2" onclick="findById(`+ cursos.id + `); bloquearBotonEnvio();" data-bs-toggle="modal" data-bs-target="#myModal"><i class="fa-solid fa-user-pen"></i></button>
                                    <button type="button" class="btn btn-danger" onclick="deleteById(`+ cursos.id + `);"><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                            `;
            })
            $("#dataResult").html(registros);
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

function findById(id) {
    $(document).ready(function () {
        // Realizar una petición Ajax para obtener la información de la modulos por su ID
        $.ajax({
            url: 'http://localhost:9000/api/listaAsistencia/cursos/' + id,
            type: 'GET',
            dataType: 'json',
            success: function (cursos) {
                // Rellenar los campos del formulario con la información de la modulos
                $('#id').val(cursos.id);
                $('#nombreCurso').val(cursos.nombreCurso);
                $('#materiasId').val(cursos.materiasId.id);
                $('#usuariosId').val(cursos.usuariosId.id);
                $('#horaInicio').val(cursos.horaInicio);
                $('#horaFin').val(cursos.horaFin);
                $('#state').val(cursos.state);
                Swal.fire({
                    title: "cursos encontrados",
                    icon: "success"
                });
                habilitarBotonGuardar();
            },
            error: function (jqXHR, textStatus, errorThrown) {
                Swal.fire({
                    title: "cursos no encontrados",
                    icon: "error"
                });
                console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
            }
        });
    });
}

function agragarcurso() {

    var id = $('#id').val();
    var formData = {
        materiasId:{
            id: $('#materiasId').val()
        },
        usuariosId:{
            id: $('#usuariosId').val()
        },
        horaInicio: $('#horaInicio').val(),
        horaFin: $('#horaFin').val(),
        state: $('#state').val(),

    };

    $.ajax({
        type: 'POST',
        url: 'http://localhost:9000/api/listaAsistencia/cursos',
        data: JSON.stringify(formData),
        contentType: 'application/json',
        success: function () {
            Swal.fire({
                title: "cursos registrados",
                icon: "success"
            });
            loadTable();
            Limpiar();
        },
        error: function () {
            Swal.fire({
                title: "Ha ocurrido un error al registrar los cursos",
                icon: "error"
            });
        }
    });
}

// Guardar cambios modulos.

function guardarCambios() {
    $(document).ready(function () {

        var id = $('#id').val();

        var formData = {
            materiasId:{
                id: $('#materiasId').val()
            },
            usuariosId:{
                id: $('#usuariosId').val()
            },
            horaInicio: $('#horaInicio').val(),
            horaFin: $('#horaFin').val(),
            state: $('#state').val(),
        };

        $.ajax({
            url: 'http://localhost:9000/api/listaAsistencia/cursos/' + id,
            type: 'Put',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            success: function () {
                Swal.fire({
                    title: "cursos actualizados",
                    icon: "success"
                });
                loadTable();
                bloquearBotonGuardar();
                habilitarBotonEnvio();
                Limpiar();
            },
            error: function () {
                Swal.fire({
                    title: "Ha ocurrido un error al actualizar los cursos",
                    icon: "error"
                });
            }
        });
    });
}


//Accion para eliminar un registro seleccionado 

function deleteById(id) {
    $.ajax({
        url: 'http://localhost:9000/api/listaAsistencia/cursos/' + id,
        method: "delete",
        headers: {
            "Content-Type": "application/json"
        },
        success: function (result) {
            Swal.fire({
                title: "cursos Eliminados",
                icon: "success"
            });
            loadTable();
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.log('Error al realizar la petición Ajax: ' + textStatus + ', ' + errorThrown);
        }
    });
}


// Habilitar y  Deshabilitar botones

function bloquearBotonEnvio() {
    document.getElementById("btnEnviar").disabled = true;
}

function bloquearBotonGuardar() {
    document.getElementById("btnGuardar").disabled = true;
}

function habilitarBotonEnvio() {
    document.getElementById("btnEnviar").disabled = false;
}

function habilitarBotonGuardar() {
    document.getElementById("btnGuardar").disabled = false;
}


function Limpiar() {
    $('#materiasId').val('');
    $('#usuariosId').val('');
    $('#horaInicio').val('');
    $('#horaFin').val('');
    $('#state').val('0');
}