function signIn() {
  
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;

  // Realizar la solicitud a la API para obtener los usuarios
  $.ajax({
    url: 'http://localhost:9000/api/security/usuario',
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    },
    success: function (items) {
      const userExists = items.some(function (user) {
        return user.user === username && user.password === password;
      });

      if (userExists) {
        // Almacenar el usuario y la contraseña en sessionStorage
        sessionStorage.setItem("username", username);
        sessionStorage.setItem("password", password);

        Swal.fire({
          icon: "success",
          title: "¡Inicio de sesión exitoso!",
          text: "Has iniciado sesión correctamente.",
          timer: 2000,
          showConfirmButton: false
        }).then(function() {
          window.location.href = "dashboard.html";
        });
      } else {
        Swal.fire({
          icon: "error",
          title: "Error al autenticar",
          text: "El usuario o la contraseña son incorrectos.",
          showConfirmButton: false
        }).then(function() {
          setTimeout(function() {
            window.location.reload();
          }, 2000);
        });
      }
    },
    error: function(xhr, status, error) {
      console.log("Ha ocurrido un error: " + error);
    }
  });
}

function signOut() {
  // Realizar cualquier operación necesaria antes de cerrar sesión
  
  // Mostrar alerta de despedida
  Swal.fire({
    title: "¡Adiós!",
    text: "Fin de la session",
    icon: "info",
    confirmButtonText: "Aceptar"
  }).then(() => {
    // Redireccionar al usuario a login.html
    window.location.href = "login.html";
  });
}


function loadPermission() {
  // Obtener el usuario y la contraseña almacenados en sessionStorage
  let username = sessionStorage.getItem("username");
  let password = sessionStorage.getItem("password");

  // Verificar si hay usuario y contraseña almacenados
  if (username && password) {
    $.ajax({
      url: 'http://localhost:9000/api/security/usuario/permission/' + username + '/' + password,
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      },
      success: function (items) {
        var permissionHTML = "";
        items.forEach(function (permission, index, array) {
          permissionHTML += `
            <div class="item">
              <div class="item separator"></div>
              <a href="#" onclick="loadView('${permission.moduleRoute}/${permission.viewRoute}')">
                <div class="icon"><i class="${permission.viewIcon}"></i></div>
                <div class="title"><span>${permission.viewLabel}</span></div>
              </a>
            </div>
          `;
        });

        $("#dataPermission").html(permissionHTML);
      }
    });
  }
}

function loadView(url) {
  $("#content-frame").attr("src", url);
}