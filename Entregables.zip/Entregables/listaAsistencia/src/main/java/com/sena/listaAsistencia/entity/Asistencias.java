package com.sena.listaAsistencia.entity;

import java.util.Date;

import com.sena.listaAsistencia.seguridad.Entity.BaseModel;
import com.sena.listaAsistencia.seguridad.Entity.Usuarios;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "asistencia")
public class Asistencias extends BaseModel{

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_materia", nullable = false, unique = true)
	private Materias materias;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_usuario", nullable = false, unique = true)
	private Usuarios usuario;
	
	@Column(name = "fecha_inscripcion", nullable = false, length = 45)
	@Schema(description = "fecha de la inscripcion  ", required = true, maxLength = 45)
	private Date fechaInscripcion;

	public Materias getMaterias() {
		return materias;
	}

	public void setMaterias(Materias materias) {
		this.materias = materias;
	}

	public Usuarios getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuarios usuario) {
		this.usuario = usuario;
	}

	public Date getFechaInscripcion() {
		return fechaInscripcion;
	}

	public void setFechaInscripcion(Date fechaInscripcion) {
		this.fechaInscripcion = fechaInscripcion;
	}
	
	
}
