package com.sena.listaAsistencia.seguridad.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.seguridad.DTO.IModulosDTO;
import com.sena.listaAsistencia.seguridad.Entity.Modulos;
import com.sena.listaAsistencia.seguridad.IRepositorio.IModulosRepositorios;
import com.sena.listaAsistencia.seguridad.IServicio.IModulosServicio;

@Service
public class ModulosServicio implements IModulosServicio{

	@Autowired
	private IModulosRepositorios repositorio;
	
	@Override
	public List<Modulos> all() throws Exception{
		return repositorio.findAll();
	}
	
	@Override
	public Optional<Modulos> findById(Integer id) throws Exception{
		Optional<Modulos> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}

	@Override
	public Modulos save(Modulos modulos) throws Exception{
		Optional<IModulosDTO> op = repositorio.getValidate(modulos.getCodigo(),modulos.getRuta());
    	if (op.get().getQuantity()>=1) {
            throw new Exception("Validar datos, ya existe registro con este código o ruta.");
        }
    	
    	return repositorio.save(modulos);
	}
	
    @Override
    public void update(Integer id, Modulos modulos) throws Exception {
    	Optional<Modulos> optionalModulos = this.repositorio.findById(id);

        if (optionalModulos.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        Modulos modulosToUpdate = optionalModulos.get();
        BeanUtils.copyProperties(modulos, modulosToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

        this.repositorio.save(modulosToUpdate);
    }
    
	@Override
	public void delete(Integer id) throws Exception {
		Optional<Modulos> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        repositorio.deleteById(id);		
	}		
	
    @Override
	public Page<IModulosDTO> getDatatable(Pageable pageable, String search) throws Exception{
		return repositorio.getDatatable(pageable, search);
	}
}
