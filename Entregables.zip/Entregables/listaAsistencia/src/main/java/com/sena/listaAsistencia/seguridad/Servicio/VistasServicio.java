package com.sena.listaAsistencia.seguridad.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.seguridad.DTO.IVistasDTO;
import com.sena.listaAsistencia.seguridad.Entity.Vistas;
import com.sena.listaAsistencia.seguridad.IRepositorio.IVistasRepositorio;
import com.sena.listaAsistencia.seguridad.IServicio.IVistasServicio;

@Service
public class VistasServicio implements IVistasServicio  {

	@Autowired
	private IVistasRepositorio repositorio;

	@Override
	public List<Vistas> all() throws Exception{		
		return repositorio.findAll();
	}

	@Override
	public Optional<Vistas> findById(Integer id) throws Exception{
        Optional<Vistas> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}

	@Override
	public Vistas save(Vistas vistas) throws Exception{
		Optional<IVistasDTO> op = repositorio.getValidate(vistas.getCodigo(),vistas.getRuta());
    	if (op.get().getQuantity()>=1) {
            throw new Exception("Validar datos, ya existe registro con este código o ruta.");
        }
        return repositorio.save(vistas);
	}

    @Override
    public void update(Integer id, Vistas vistas) throws Exception {
		Optional<Vistas> optionalVistas = this.repositorio.findById(id);

        if (optionalVistas.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        Vistas VistasToUpdate = optionalVistas.get();
        BeanUtils.copyProperties(vistas, VistasToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

        this.repositorio.save(VistasToUpdate);
    }
    
	@Override
	public void delete(Integer id) throws Exception{
        Optional<Vistas> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        repositorio.deleteById(id);
	}
	
    @Override
	public Page<IVistasDTO> getDatatable(Pageable pageable, String search) throws Exception{
		return repositorio.getDatatable(pageable, search);
	}	
}
