package com.sena.listaAsistencia.seguridad.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.seguridad.DTO.IRolesDTO;
import com.sena.listaAsistencia.seguridad.Entity.Roles;
import com.sena.listaAsistencia.seguridad.IRepositorio.IRolesRepositorio;
import com.sena.listaAsistencia.seguridad.IServicio.IRolesServicio;

@Service
public class RolesServicio implements IRolesServicio {
	
	@Autowired
	private IRolesRepositorio repositorio;

	@Override
	public List<Roles> all() throws Exception{
		return repositorio.findAll();
	}
	
	@Override
	public Optional<Roles> findById(Integer id) throws Exception{
        Optional<Roles> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}
	
	@Override
	public Roles save(Roles roles) throws Exception{
		Optional<IRolesDTO> op = repositorio.getValidate(roles.getCodigo(),roles.getDescripcion());
    	if (op.get().getQuantity()>=1) {
            throw new Exception("Validar datos, ya existe registro con este código o descripción.");
        }
    	return repositorio.save(roles);
	}
	
    @Override
    public void update(Integer id, Roles roles) throws Exception {
    	Optional<Roles> optionalRoles = this.repositorio.findById(id);

        if (optionalRoles.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        Roles rolesToUpdate = optionalRoles.get();
        BeanUtils.copyProperties(roles, rolesToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

        this.repositorio.save(rolesToUpdate);
    }

	@Override
	public void delete(Integer id) throws Exception{
        Optional<Roles> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        repositorio.deleteById(id);		
	}

    @Override
	public Page<IRolesDTO> getDatatable(Pageable pageable, String search) throws Exception{
		return repositorio.getDatatable(pageable, search);
	}	
}
