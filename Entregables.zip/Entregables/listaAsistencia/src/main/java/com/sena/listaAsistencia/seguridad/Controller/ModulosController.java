package com.sena.listaAsistencia.seguridad.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sena.listaAsistencia.DTO.ApiResponseDto;
import com.sena.listaAsistencia.seguridad.Entity.Modulos;
import com.sena.listaAsistencia.seguridad.IServicio.IModulosServicio;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/seguridad/modulos")
public class ModulosController {

	@Autowired
	private IModulosServicio servicio;
	
	@Operation(summary = "Obtener todos los módulos", responses = {
            @ApiResponse(responseCode = "200", description = "Lista de módulos obtenida"),
            @ApiResponse(responseCode = "404", description = "No se encontraron módulos")
    })
	
	@GetMapping
	public List<Modulos> all() throws Exception{
		return servicio.all();
	}
	
    @Operation(summary = "Obtener un módulo por ID", responses = {
            @ApiResponse(responseCode = "200", description = "Módulo encontrado"),
            @ApiResponse(responseCode = "404", description = "Módulo no encontrado")
    })
	
	@GetMapping("{id}")
	public Optional<Modulos> show(@PathVariable Integer id) throws Exception{
		return servicio.findById(id);
	}
	
	@Operation(summary = "Crear un nuevo módulo", responses = {
			@ApiResponse(responseCode = "201", description = "Módulo creado")
	 })
	
	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Modulos save(@RequestBody Modulos modulos) throws Exception{
		return servicio.save(modulos);
	}
	

    @Operation(summary = "Actualizar un módulo existente", responses = {
            @ApiResponse(responseCode = "200", description = "Módulo actualizado"),
            @ApiResponse(responseCode = "404", description = "Módulo no encontrado")
    })
	
	@PutMapping("{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<ApiResponseDto<Modulos>> update(@PathVariable Integer id, @RequestBody Modulos modulos) {
        try {
        	servicio.update(id, modulos);
            return ResponseEntity.ok(new ApiResponseDto<Modulos>("Datos actualizados", null, true));
        } catch (Exception e) {
        	return ResponseEntity.internalServerError().body(new ApiResponseDto<Modulos>(e.getMessage(), null, false));
        }
    }
	
    @Operation(summary = "Eliminar un módulo existente", responses = {
            @ApiResponse(responseCode = "204", description = "Módulo eliminado"),
            @ApiResponse(responseCode = "404", description = "Módulo no encontrado")
    })
    
	@DeleteMapping("{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Integer id) throws Exception{
    	servicio.delete(id);
	}

    @GetMapping("/datatable")
    public ResponseEntity<ApiResponseDto<Page<?>>> datatable(@RequestParam(name = "page") Integer page,
            @RequestParam(name = "size") Integer size,
            @RequestParam(name = "column_order") String columnOrder,
            @RequestParam(name = "column_direction") String columnDirection,
            @RequestParam(name = "search", required = false) String search) {
        try {
            List<Order> orders = new ArrayList<>();

            orders.add(new Order(columnDirection == "asc" ? Direction.ASC : Direction.DESC, columnOrder));

            return ResponseEntity.ok(new ApiResponseDto<Page<?>>("Datos obtenidos",
            		servicio.getDatatable(PageRequest.of(page, size, Sort.by(orders)), search), true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Page<?>>(e.getMessage(), null, false));
        }
    }
}
