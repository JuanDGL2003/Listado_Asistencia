package com.sena.listaAsistencia.seguridad.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sena.listaAsistencia.DTO.ApiResponseDto;
import com.sena.listaAsistencia.seguridad.Entity.Roles;
import com.sena.listaAsistencia.seguridad.IServicio.IRolesServicio;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/seguridad/roles")


public class RolesController {
	
	@Autowired
	private IRolesServicio service;
	
    @Operation(summary = "Obtener todos los roles", responses = {
            @ApiResponse(responseCode = "200", description = "Lista de roles obtenida"),
            @ApiResponse(responseCode = "404", description = "No se encontraron roles")
    })
	
	@GetMapping
	public List<Roles> all() throws Exception{
		return service.all();
	}

    @Operation(summary = "Obtener un rol por ID", responses = {
            @ApiResponse(responseCode = "200", description = "Rol encontrado"),
            @ApiResponse(responseCode = "404", description = "Rol no encontrado")
    })
    
	@GetMapping("{id}")
	public Optional<Roles> show(@PathVariable Integer id) throws Exception{
		return service.findById(id);
	}
	
    @Operation(summary = "Crear un nuevo rol", responses = {
            @ApiResponse(responseCode = "201", description = "Rol creado")
    })
    
	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Roles save(@RequestBody Roles roles) throws Exception{
		return service.save(roles);
	}
	
    @Operation(summary = "Actualizar un rol existente", responses = {
            @ApiResponse(responseCode = "200", description = "Rol actualizado"),
            @ApiResponse(responseCode = "404", description = "Rol no encontrado")
    })
    
	@PutMapping("{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<ApiResponseDto<Roles>> update(@PathVariable Integer id, @RequestBody Roles roles) {
        try {
            service.update(id, roles);
            return ResponseEntity.ok(new ApiResponseDto<Roles>("Datos actualizados", null, true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Roles>(e.getMessage(), null, false));
        }
    }
	
    @Operation(summary = "Eliminar un rol existente", responses = {
            @ApiResponse(responseCode = "204", description = "Rol eliminado"),
            @ApiResponse(responseCode = "404", description = "Rol no encontrado")
    })
    
	@DeleteMapping("{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Integer id) throws Exception{
		service.delete(id);
	}
    
    @GetMapping("/datatable")
    public ResponseEntity<ApiResponseDto<Page<?>>> datatable(@RequestParam(name = "page") Integer page,
            @RequestParam(name = "size") Integer size,
            @RequestParam(name = "column_order") String columnOrder,
            @RequestParam(name = "column_direction") String columnDirection,
            @RequestParam(name = "search", required = false) String search) {
        try {
            List<Order> orders = new ArrayList<>();

            orders.add(new Order(columnDirection == "asc" ? Direction.ASC : Direction.DESC, columnOrder));

            return ResponseEntity.ok(new ApiResponseDto<Page<?>>("Datos obtenidos",
                    service.getDatatable(PageRequest.of(page, size, Sort.by(orders)), search), true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Page<?>>(e.getMessage(), null, false));
        }
    }
	
}
