package com.sena.listaAsistencia.seguridad.Entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 * Clase que representa un módulo en el sistema.
 * Extiende la clase BaseModel que proporciona los campos comunes.
 */
@Entity
@Table(name = "modulos")
@Schema(description = "Entidad que representa un modulo en el sistema")
public class Modulos extends BaseModel{

	@Column(name = "codigo", nullable = false, unique = true)
	@Schema(description = "Código del módulo", required = true)
    private String codigo;

    @Column(name = "ruta",  length = 150, unique = true, nullable = false)
	@Schema(description = "Ruta del módulo", maxLength = 150)
    private String ruta;

	
    @Column(name = "etiqueta", nullable = false, unique = true, length = 50)
	@Schema(description = "Etiqueta del módulo", required = true, maxLength = 100)
    private String etiqueta;


	public String getCodigo() {
		return codigo;
	}


	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}


	public String getRuta() {
		return ruta;
	}


	public void setRuta(String ruta) {
		this.ruta = ruta;
	}


	public String getEtiqueta() {
		return etiqueta;
	}


	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}


	
    

}
