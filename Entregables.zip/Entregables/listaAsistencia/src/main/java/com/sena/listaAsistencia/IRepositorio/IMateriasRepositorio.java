package com.sena.listaAsistencia.IRepositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.listaAsistencia.entity.Materias;

public interface IMateriasRepositorio extends JpaRepository<Materias, Integer> {

}
