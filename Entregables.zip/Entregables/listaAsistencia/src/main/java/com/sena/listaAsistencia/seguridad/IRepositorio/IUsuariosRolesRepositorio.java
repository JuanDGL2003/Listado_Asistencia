package com.sena.listaAsistencia.seguridad.IRepositorio;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sena.listaAsistencia.seguridad.DTO.IUsuariosRolesDTO;
import com.sena.listaAsistencia.seguridad.Entity.UsuariosRoles;

public interface IUsuariosRolesRepositorio extends JpaRepository<UsuariosRoles, Integer>{

	@Query(value = "SELECT * FROM usuarios", nativeQuery = true)
    Page<IUsuariosRolesDTO> getDatatable(Pageable pageable, String search);
}
