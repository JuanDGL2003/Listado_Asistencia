package com.sena.listaAsistencia.seguridad.IRepositorio;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.sena.listaAsistencia.seguridad.DTO.ILoginDTO;
import com.sena.listaAsistencia.seguridad.DTO.IPermissionDTO;
import com.sena.listaAsistencia.seguridad.DTO.IUsuariosDTO;
import com.sena.listaAsistencia.seguridad.Entity.Usuarios;

public interface IUsuariosRepositorio extends JpaRepository<Usuarios, Integer> {
		@Query(value = " SELECT  "
					+ " v.ruta vistasRuta,"
					+ " v.etiqueta vistasEtiqueta,"
					+ "	v.icono vistasIcono,"
					+ " m.ruta modulosRuta, "
					+ " m.etiqueta modulosEtiqueta "
					+ "FROM  "
					+ "	usuario u  "
					+ "	INNER JOIN usuarios_roles ur ON ur.usuarios_id = u.id "
					+ " INNER JOIN roles r ON r.id = ur.roles_id "
					+ " INNER JOIN vistas_roles vr ON vr.roles_id = r.id "
					+ " INNER JOIN vistas v ON v.id = vr.vistas_id "
					+ " INNER JOIN modulos m ON m.id = v.modulos_id "
					+ "WHERE  "
					+ "	u.usuario = :usuario  "
					+ " AND u.state = 'Activo' "
					+ " AND u.contraseña = :contraseña "
					+ " AND r.state = 'Activo' "
					+ " AND v.state = 'Activo' "
					+ " AND m.state = 'Activo' "
					+ " AND ur.state = 'Activo' "
					+ " AND vr.state = 'Activo' ", nativeQuery = true)
		List<IPermissionDTO> getPermission(String usuario, String contraseña);
		
		@Query(value = " SELECT "		
				+ " u.state state, "	
				+ " u.usuario user"
				+ " FROM "
				+ " usurios u "			
				+ " WHERE "
				+ " u.usurios = :usuario AND u.contraseña = :contraseña AND u.state = 'Activo' ", nativeQuery = true)
		Optional<ILoginDTO> getLogin(String usuario, String contraseña);
		
		@Query(value = "SELECT * FROM usurios", nativeQuery = true)
		Page<IUsuariosDTO> getDatatable(Pageable pageable, String search);
		
}
