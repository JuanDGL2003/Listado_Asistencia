package com.sena.listaAsistencia.seguridad.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sena.listaAsistencia.DTO.ApiResponseDto;
import com.sena.listaAsistencia.seguridad.DTO.ILoginDTO;
import com.sena.listaAsistencia.seguridad.DTO.IPermissionDTO;
import com.sena.listaAsistencia.seguridad.Entity.Usuarios;
import com.sena.listaAsistencia.seguridad.IServicio.IUsuariosServicio;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/seguridad/usuarios")

public class UsuariosController {
	
	@Autowired
	private IUsuariosServicio service;

    @Operation(summary = "Obtener todos los usuarios", responses = {
            @ApiResponse(responseCode = "200", description = "Lista de usuarios obtenida"),
            @ApiResponse(responseCode = "404", description = "No se encontraron usuarios")
    })
	
	@GetMapping
	public List<Usuarios> all() throws Exception{
		return service.all();
	}

    @Operation(summary = "Obtener un usuario por ID", responses = {
            @ApiResponse(responseCode = "200", description = "Usuario encontrado"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    
	@GetMapping("{id}")
	public Optional<Usuarios> show(@PathVariable Integer id) throws Exception{
		return service.findById(id);
	}

    @Operation(summary = "Crear un nuevo usuario", responses = {
            @ApiResponse(responseCode = "201", description = "Usuario creado")
    })

	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Usuarios save(@RequestBody Usuarios usuario) throws Exception{
		return service.save(usuario);
	}

    @Operation(summary = "Actualizar un usuario existente", responses = {
            @ApiResponse(responseCode = "200", description = "Usuario actualizado"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    
	@PutMapping("{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<ApiResponseDto<Usuarios>> update(@PathVariable Integer id, @RequestBody Usuarios usuario) {
        try {
            service.update(id, usuario);
            return ResponseEntity.ok(new ApiResponseDto<Usuarios>("Datos actualizados", null, true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Usuarios>(e.getMessage(), null, false));
        }
    }
    
    @Operation(summary = "Obtener los permisos de un usuario", responses = {
            @ApiResponse(responseCode = "200", description = "Permisos obtenidos"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    
    @GetMapping("/permission/{usuario}/{contraseña}")
    public List<IPermissionDTO> getPermission(
            @Parameter(description = "Nombre de usuario") @PathVariable String usuario,
            @Parameter(description = "Contraseña") @PathVariable String contraseña) throws Exception{
        return service.getPermission(usuario, contraseña);
    }

    @Operation(summary = "Obtener la información de inicio de sesión de un usuario", responses = {
            @ApiResponse(responseCode = "200", description = "Información de inicio de sesión obtenida"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    
    @GetMapping("/login/{user}/{password}")
    public Optional<ILoginDTO> getLogin(
            @Parameter(description = "Nombre de usuario") @PathVariable String user,
            @Parameter(description = "Contraseña") @PathVariable String password) throws Exception{
        return service.getLogin(user, password);
    }

    @Operation(summary = "Eliminar un usuario existente", responses = {
            @ApiResponse(responseCode = "204", description = "Usuario eliminado"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado")
    })
    
	@DeleteMapping("{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Integer id) throws Exception{
		service.delete(id);
	}

    @GetMapping("/datatable")
    public ResponseEntity<ApiResponseDto<Page<?>>> datatable(@RequestParam(name = "page") Integer page,
            @RequestParam(name = "size") Integer size,
            @RequestParam(name = "column_order") String columnOrder,
            @RequestParam(name = "column_direction") String columnDirection,
            @RequestParam(name = "search", required = false) String search) {
        try {
            List<Order> orders = new ArrayList<>();

            orders.add(new Order(columnDirection == "asc" ? Direction.ASC : Direction.DESC, columnOrder));

            return ResponseEntity.ok(new ApiResponseDto<Page<?>>("Datos obtenidos",
                    service.getDatatable(PageRequest.of(page, size, Sort.by(orders)), search), true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Page<?>>(e.getMessage(), null, false));
        }
    }
}
