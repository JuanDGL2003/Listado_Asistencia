package com.sena.listaAsistencia.seguridad.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.seguridad.DTO.IVistaRolesDTO;
import com.sena.listaAsistencia.seguridad.Entity.VistasRoles;
import com.sena.listaAsistencia.seguridad.IRepositorio.IVistasRolesRepositorio;
import com.sena.listaAsistencia.seguridad.IServicio.IVistasRolesServicio;

@Service
public class VistasRolesServicio implements IVistasRolesServicio{

	@Autowired
	private IVistasRolesRepositorio repository;
	
	@Override
	public List<VistasRoles> all() throws Exception{
		return repository.findAll();
	}

	@Override
	public Optional<VistasRoles> findById(Integer id) throws Exception{
        Optional<VistasRoles> op = repository.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}

	@Override
	public VistasRoles save(VistasRoles vistaRole) throws Exception{
		return repository.save(vistaRole);
	}
	
    @Override
    public void update(Integer id, VistasRoles vistaRole) throws Exception {
    	Optional<VistasRoles> optionalVistasRoles = this.repository.findById(id);

        if (optionalVistasRoles.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        VistasRoles vistasRolesToUpdate = optionalVistasRoles.get();
        BeanUtils.copyProperties(vistaRole, vistasRolesToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

        this.repository.save(vistasRolesToUpdate);
    }

	@Override
	public void delete(Integer id) throws Exception{
        Optional<VistasRoles> op = repository.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        repository.deleteById(id);
	}
	
    @Override
	public Page<IVistaRolesDTO> getDatatable(Pageable pageable, String search) throws Exception{
		return repository.getDatatable(pageable, search);
	}	
}
