package com.sena.listaAsistencia.seguridad.DTO;

public interface IModulosDTO {

	/**
     * Obtiene el código del modulo.
     *
     * @return el estado del modulo
     */
    String getCodigo();
    
    /**
     * Obtiene la ruta del modulo.
     *
     * @return la ruta del modulo
     */
    String getRuta();
    
    /**
     * Obtiene la etiqueta del modulo.
     *
     * @return la etiqueta del modulo
     */
    String getEtiqueta();
    
    /**
     * Obtiene la cantidad del modulo.
     *
     * @return la cantidad del modulo
     */
    Integer getQuantity();
}

