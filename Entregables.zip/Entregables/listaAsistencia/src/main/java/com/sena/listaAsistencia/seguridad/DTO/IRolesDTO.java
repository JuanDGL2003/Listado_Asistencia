package com.sena.listaAsistencia.seguridad.DTO;

public interface IRolesDTO {

	String getCodigo();
	
    String getDescripcion();   
    
    Integer getQuantity();
}
