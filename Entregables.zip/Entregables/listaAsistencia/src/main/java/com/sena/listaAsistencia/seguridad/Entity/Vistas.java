package com.sena.listaAsistencia.seguridad.Entity;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Clase que representa a una vista en el sistema.
 * Extiende la clase BaseModel que proporciona los campos comunes.
 */
@Entity
@Table(name = "vistas")
@Schema(description = "Entidad que representa una vista en el sistema")
public class Vistas extends BaseModel{

	@ManyToOne (fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "modulos_id",  nullable = false)
    @Schema(description = "Identificador del módulo al que pertenece la vista")
    private Modulos modulosId;
	
    @Column(name = "codigo", nullable = false, unique = true)
	@Schema(description = "Código de la vista")
    private String codigo;
	
    @Column (name = "icono", nullable = false)
	@Schema(description = "Ícono de la vista")
	private String icono;
    
	@Column(name = "ruta", nullable = false, length = 150, unique = true)
	@Schema(description = "Ruta de la vista")
    private String ruta;

    @Column(name = "etiqueta", nullable = false,  length = 50)
	@Schema(description = "Etiqueta de la vista")
    private String etiqueta;

	public Modulos getModulosId() {
		return modulosId;
	}

	public void setModulosId(Modulos modulosId) {
		this.modulosId = modulosId;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getIcono() {
		return icono;
	}

	public void setIcono(String icono) {
		this.icono = icono;
	}

	public String getRuta() {
		return ruta;
	}

	public void setRuta(String ruta) {
		this.ruta = ruta;
	}

	public String getEtiqueta() {
		return etiqueta;
	}

	public void setEtiqueta(String etiqueta) {
		this.etiqueta = etiqueta;
	}
    
    
}
