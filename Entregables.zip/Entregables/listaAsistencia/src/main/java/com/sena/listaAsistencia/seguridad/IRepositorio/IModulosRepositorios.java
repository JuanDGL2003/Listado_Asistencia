package com.sena.listaAsistencia.seguridad.IRepositorio;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sena.listaAsistencia.seguridad.DTO.IModulosDTO;
import com.sena.listaAsistencia.seguridad.Entity.Modulos;


public interface IModulosRepositorios extends JpaRepository<Modulos, Integer>{

	@Query(value = "SELECT "
			+ " codigo, "
			+ " ruta, "
			+ " labetiquetael, "
			+ " FROM "
			+ " modulos", nativeQuery = true)
Page<IModulosDTO> getDatatable(Pageable pageable, String search);

@Query(value = "SELECT "
			+ " 	count(codigo) as quantity "
			+ " FROM "
			+ " 	modulos "
			+ " WHERE codigo = :codigo "
			+ " OR ruta = :ruta ", nativeQuery = true)
Optional<IModulosDTO> getValidate(String codigo, String ruta);
}
