package com.sena.listaAsistencia.IServicio;

import java.util.List;
import java.util.Optional;


import com.sena.listaAsistencia.entity.Asistencias;


public interface IAsistenciasServicio {
 
public List<Asistencias> all() throws Exception;
	
	public Optional<Asistencias> findById(Integer id) throws Exception;

	public Asistencias save(Asistencias asistencias) throws Exception;

	public void update(Integer id, Asistencias asistencias) throws Exception;

	public void delete(Integer id) throws Exception;
}
