package com.sena.listaAsistencia.seguridad.IRepositorio;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sena.listaAsistencia.seguridad.DTO.IRolesDTO;
import com.sena.listaAsistencia.seguridad.Entity.Roles;

public interface IRolesRepositorio extends JpaRepository<Roles, Integer> {

	@Query(value = "SELECT * FROM usuarios", nativeQuery = true)
    Page<IRolesDTO> getDatatable(Pageable pageable, String search);
	
	@Query(value = "SELECT "
			+ " count(codigo) as quantity "
			+ " FROM "
			+ " roles "
			+ " WHERE codigo = :codigo "
			+ " OR descripcion = :descripcion ", nativeQuery = true)
		Optional<IRolesDTO> getValidate(String codigo, String descripcion);
}
