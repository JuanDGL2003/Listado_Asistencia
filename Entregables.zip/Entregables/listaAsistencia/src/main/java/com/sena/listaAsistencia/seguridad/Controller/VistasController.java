package com.sena.listaAsistencia.seguridad.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sena.listaAsistencia.DTO.ApiResponseDto;
import com.sena.listaAsistencia.seguridad.Entity.Vistas;
import com.sena.listaAsistencia.seguridad.IServicio.IVistasServicio;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/seguridad/vistas")
public class VistasController {

	@Autowired
	private IVistasServicio servicio;
	
    @Operation(summary = "Obtener todas las vistas", responses = {
            @ApiResponse(responseCode = "200", description = "Lista de vistas obtenida"),
            @ApiResponse(responseCode = "404", description = "No se encontraron vistas")
    })
	
	@GetMapping
	public List<Vistas> all() throws Exception{
		return servicio.all();
	}

    @Operation(summary = "Obtener una vista por ID", responses = {
            @ApiResponse(responseCode = "200", description = "Vista encontrada"),
            @ApiResponse(responseCode = "404", description = "Vista no encontrada")
    })
   
	@GetMapping("{id}")
	public Optional<Vistas> show(@PathVariable Integer id) throws Exception{
		return servicio.findById(id);
	}
    
    @Operation(summary = "Crear una nueva vista", responses = {
            @ApiResponse(responseCode = "201", description = "Vista creada")
    })
	
	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Vistas save(@RequestBody Vistas vistas) throws Exception{
		return servicio.save(vistas);
	}
    
    @Operation(summary = "Actualizar una vista existente", responses = {
            @ApiResponse(responseCode = "200", description = "Vista actualizada"),
            @ApiResponse(responseCode = "404", description = "Vista no encontrada")
    })
	
	@PutMapping("{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<ApiResponseDto<Vistas>> update(@PathVariable Integer id, @RequestBody Vistas vistas) {
        try {
        	servicio.update(id, vistas);
            return ResponseEntity.ok(new ApiResponseDto <Vistas> ("Datos actualizados", null, true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Vistas>(e.getMessage(), null, false));
        }
    }
	
    @Operation(summary = "Eliminar una vista existente", responses = {
            @ApiResponse(responseCode = "204", description = "Vista eliminada"),
            @ApiResponse(responseCode = "404", description = "Vista no encontrada")
    })
    
	@DeleteMapping("{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Integer id) throws Exception{
    	servicio.delete(id);
	}

    @GetMapping("/datatable")
    public ResponseEntity<ApiResponseDto<Page<?>>> datatable(@RequestParam(name = "page") Integer page,
            @RequestParam(name = "size") Integer size,
            @RequestParam(name = "column_order") String columnOrder,
            @RequestParam(name = "column_direction") String columnDirection,
            @RequestParam(name = "search", required = false) String search) {
        try {
            List<Order> orders = new ArrayList<>();

            orders.add(new Order(columnDirection == "asc" ? Direction.ASC : Direction.DESC, columnOrder));

            return ResponseEntity.ok(new ApiResponseDto<Page<?>>("Datos obtenidos",
            		servicio.getDatatable(PageRequest.of(page, size, Sort.by(orders)), search), true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Page<?>>(e.getMessage(), null, false));
        }
    }
}
