package com.sena.listaAsistencia.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.IRepositorio.ICursosRepositorio;
import com.sena.listaAsistencia.IServicio.ICursosServicio;
import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.entity.Cursos;

@Service
public class CursosServicio implements ICursosServicio{

	@Autowired
	private ICursosRepositorio repositorio;

	@Override
	public List<Cursos> all() throws Exception{
		return repositorio.findAll();
	}
	
	@Override
	public Optional<Cursos> findById(Integer id) throws Exception{
        Optional<Cursos> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}
	
	@Override
	public Cursos save(Cursos cursos) throws Exception{
		return repositorio.save(cursos);
	}
	
	 @Override
	    public void update(Integer id, Cursos cursos) throws Exception {
	    	Optional<Cursos> optionalCursos = this.repositorio.findById(id);

	        if (optionalCursos.isEmpty()) {
	            throw new Exception("No se encontró registro");
	        }

	        Cursos cursosToUpdate = optionalCursos.get();
	        BeanUtils.copyProperties(cursos,cursosToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

	        this.repositorio.save(cursosToUpdate);
	    }
	 @Override
	 public void delete(Integer id) throws Exception{
		 Optional<Cursos> op = repositorio.findById(id);
	        if (op.isEmpty()) {
	            throw new Exception("No se encontró registro");
	        }
	        repositorio.deleteById(id);		
	}
}
