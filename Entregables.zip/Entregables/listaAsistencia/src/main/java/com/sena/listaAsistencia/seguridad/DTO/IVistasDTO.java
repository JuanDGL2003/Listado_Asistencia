package com.sena.listaAsistencia.seguridad.DTO;

public interface IVistasDTO {

	 String getCodigo();
    
	 String getIcono();
	 
	 String getRuta();
	   
	 String getEtiqueta();
	    
	 Integer getModulosId();
	    
	 Integer getQuantity();
}
