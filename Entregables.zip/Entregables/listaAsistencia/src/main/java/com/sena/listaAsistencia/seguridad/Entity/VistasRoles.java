package com.sena.listaAsistencia.seguridad.Entity;



import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Clase que representa a una roles de los usuarios en el sistema.
 * Extiende la clase BaseModel que proporciona los campos comunes.
 */
@Entity
@Table(name = "Vistas_roles")
@Schema(description = "Entidad que representa la relación entre un vista y un rol")
public class VistasRoles extends BaseModel{

	@ManyToOne (fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "roles_id", unique = false,  nullable = false)
    @Schema(description = "Identificador del rol")
    private Roles rolesId;
    
    @ManyToOne  (fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "vistas_id", unique = false,  nullable = false)
    @Schema(description = "Identificador de la vista")
    private Vistas vistasId;

	public Roles getRolesId() {
		return rolesId;
	}

	public void setRolesId(Roles rolesId) {
		this.rolesId = rolesId;
	}

	public Vistas getVistasId() {
		return vistasId;
	}

	public void setVistasId(Vistas vistasId) {
		this.vistasId = vistasId;
	}
    
    
}
