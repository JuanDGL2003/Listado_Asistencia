package com.sena.listaAsistencia.IServicio;

import java.util.List;
import java.util.Optional;

import com.sena.listaAsistencia.entity.Materias;

public interface IMateriasServicio {

	public List<Materias> all() throws Exception;
	
	public Optional<Materias> findById(Integer id) throws Exception;

	public Materias save(Materias materias) throws Exception;

	public void update(Integer id, Materias materias) throws Exception;

	public void delete(Integer id) throws Exception;
}
