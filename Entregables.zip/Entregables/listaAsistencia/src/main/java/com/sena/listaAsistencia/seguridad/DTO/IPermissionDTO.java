package com.sena.listaAsistencia.seguridad.DTO;

public interface IPermissionDTO {
	
	/**
     * Obtiene la ruta de vista asociada al permiso.
     *
     * @return la ruta de vista
     */
    String getViewRoute();

    /**
     * Obtiene la etiqueta de vista asociada al permiso.
     *
     * @return la etiqueta de vista
     */
    String getViewLabel();

    /**
     * Obtiene la ruta del módulo asociado al permiso.
     *
     * @return la ruta del módulo
     */
    String getModuleRoute();

    /**
     * Obtiene la etiqueta del módulo asociado al permiso.
     *
     * @return la etiqueta del módulo
     */
    String getModuleLabel();
    
    /**
     * Obtiene el icono del vista asociado al permiso.
     *
     * @return la icono de la vista
     */
    String getViewIcon();
}
