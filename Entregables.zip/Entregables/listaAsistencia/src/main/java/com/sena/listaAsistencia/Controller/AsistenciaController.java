package com.sena.listaAsistencia.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sena.listaAsistencia.DTO.ApiResponseDto;
import com.sena.listaAsistencia.IServicio.IAsistenciasServicio;
import com.sena.listaAsistencia.entity.Asistencias;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/listaAsistencia/asistencia")
public class AsistenciaController {

	@Autowired
	private IAsistenciasServicio service;

    @Operation(summary = "Obtener todas las asistencias", responses = {
            @ApiResponse(responseCode = "200", description = "Lista de curso obtenida"),
            @ApiResponse(responseCode = "404", description = "No se encontraron curso")
    })
	
    @GetMapping
	public List<Asistencias> all() throws Exception{
		return service.all();
	}

    @Operation(summary = "Obtener las asistencias por ID", responses = {
            @ApiResponse(responseCode = "200", description = "asistencias encontradas"),
            @ApiResponse(responseCode = "404", description = "asistencias no encontradas")
    })
    
    @GetMapping("{id}")
	public Optional<Asistencias> show(@PathVariable Integer id) throws Exception{
		return service.findById(id);
	}

    @Operation(summary = "Crear nuevas asistencias", responses = {
            @ApiResponse(responseCode = "201", description = "asistencias creadas")
    })

	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Asistencias save(@RequestBody Asistencias asistencias) throws Exception{
		return service.save(asistencias);
	}
    
    @Operation(summary = "Actualizar asistencias existente", responses = {
            @ApiResponse(responseCode = "200", description = "asistencias actualizadas"),
            @ApiResponse(responseCode = "404", description = "asistencias no encontradas")
    })
    
	@PutMapping("{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<ApiResponseDto<Asistencias>> update(@PathVariable Integer id, @RequestBody Asistencias asistencias) {
        try {
            service.update(id, asistencias);
            return ResponseEntity.ok(new ApiResponseDto<Asistencias>("Datos actualizados", null, true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Asistencias>(e.getMessage(), null, false));
        }
    }
    
    @Operation(summary = "Eliminar asistencias existente", responses = {
            @ApiResponse(responseCode = "204", description = "asistencias eliminadas"),
            @ApiResponse(responseCode = "404", description = "asistencias no encontradas")
    })
    
	@DeleteMapping("{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Integer id) throws Exception{
		service.delete(id);
	}
}
