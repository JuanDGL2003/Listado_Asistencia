package com.sena.listaAsistencia.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sena.listaAsistencia.DTO.ApiResponseDto;
import com.sena.listaAsistencia.IServicio.IMateriasServicio;
import com.sena.listaAsistencia.entity.Materias;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/listaAsistencia/materias")
public class MateriasController {
	@Autowired
	private IMateriasServicio service;

    @Operation(summary = "Obtener todas las materias", responses = {
            @ApiResponse(responseCode = "200", description = "Listas de materias obtenida"),
            @ApiResponse(responseCode = "404", description = "No se encontraron materias")
    })
	
    @GetMapping
	public List<Materias> all() throws Exception{
		return service.all();
	}

    @Operation(summary = "Obtener una materia por ID", responses = {
            @ApiResponse(responseCode = "200", description = "materia encontrada"),
            @ApiResponse(responseCode = "404", description = "materia no encontrada")
    })
    
    @GetMapping("{id}")
	public Optional<Materias> show(@PathVariable Integer id) throws Exception{
		return service.findById(id);
	}

    @Operation(summary = "Crear una nueva materia", responses = {
            @ApiResponse(responseCode = "201", description = "materia creada")
    })

	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Materias save(@RequestBody Materias materias) throws Exception{
		return service.save(materias);
	}
    
    @Operation(summary = "Actualizar una materia existente", responses = {
            @ApiResponse(responseCode = "200", description = "materia actualizada"),
            @ApiResponse(responseCode = "404", description = "materia no encontrada")
    })
    
	@PutMapping("{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<ApiResponseDto<Materias>> update(@PathVariable Integer id, @RequestBody Materias materias) {
        try {
            service.update(id, materias);
            return ResponseEntity.ok(new ApiResponseDto<Materias>("Datos actualizados", null, true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Materias>(e.getMessage(), null, false));
        }
    }
    
    @Operation(summary = "Eliminar una materia existente", responses = {
            @ApiResponse(responseCode = "204", description = "materia eliminada"),
            @ApiResponse(responseCode = "404", description = "materia no encontrada")
    })
    
	@DeleteMapping("{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Integer id) throws Exception{
		service.delete(id);
	}
}
