package com.sena.listaAsistencia.IServicio;

import java.util.List;
import java.util.Optional;

import com.sena.listaAsistencia.entity.Cursos;

public interface ICursosServicio {
public List<Cursos> all() throws Exception;
	
	public Optional<Cursos> findById(Integer id) throws Exception;

	public Cursos save(Cursos cursos) throws Exception;

	public void update(Integer id, Cursos cursos) throws Exception;

	public void delete(Integer id) throws Exception;
}

