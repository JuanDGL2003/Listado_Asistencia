package com.sena.listaAsistencia.seguridad.Servicio;

import java.util.List;



import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.seguridad.DTO.IUsuariosRolesDTO;
import com.sena.listaAsistencia.seguridad.Entity.UsuariosRoles;
import com.sena.listaAsistencia.seguridad.IRepositorio.IUsuariosRolesRepositorio;
import com.sena.listaAsistencia.seguridad.IServicio.IUsuariosRolesServicio;

@Service
public class UsuariosRolesServicio implements IUsuariosRolesServicio {

	@Autowired
	private IUsuariosRolesRepositorio repositorio;
	
	@Override
	public List<UsuariosRoles> all() throws Exception{
		return repositorio.findAll();
	}

	@Override
	public Optional<UsuariosRoles> findById(Integer id) throws Exception{
		Optional<UsuariosRoles> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}

	@Override
	public UsuariosRoles save(UsuariosRoles usuarioRoles) throws Exception{
		return repositorio.save(usuarioRoles);
	}

    @Override
    public void update(Integer id, UsuariosRoles usuarioRoles) throws Exception {
    	Optional<UsuariosRoles> optionalUsuariosRoles = this.repositorio.findById(id);

        if (optionalUsuariosRoles.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        UsuariosRoles usuariosRolesToUpdate = optionalUsuariosRoles.get();
        BeanUtils.copyProperties(usuarioRoles, usuariosRolesToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

        this.repositorio.save(usuariosRolesToUpdate);
    }
	
	@Override
	public void delete(Integer id) throws Exception{
        Optional<UsuariosRoles> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        repositorio.deleteById(id);
	}

    @Override
	public Page<IUsuariosRolesDTO> getDatatable(Pageable pageable, String search) throws Exception{
		return repositorio.getDatatable(pageable, search);
	}	
 
}
