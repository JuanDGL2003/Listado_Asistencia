package com.sena.listaAsistencia.seguridad.IRepositorio;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.sena.listaAsistencia.seguridad.DTO.IVistaRolesDTO;
import com.sena.listaAsistencia.seguridad.Entity.VistasRoles;

public interface IVistasRolesRepositorio extends JpaRepository<VistasRoles, Integer>{

	@Query(value = "SELECT * FROM usuarios", nativeQuery = true)
    Page<IVistaRolesDTO> getDatatable(Pageable pageable, String search);
}
