package com.sena.listaAsistencia.seguridad.IRepositorio;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sena.listaAsistencia.seguridad.DTO.IVistasDTO;
import com.sena.listaAsistencia.seguridad.Entity.Vistas;

public interface IVistasRepositorio extends JpaRepository<Vistas, Integer> {

	@Query(value = "SELECT "
			+ " v.codigo, "
			+ " v.ruta, "
			+ " v.icono, "
			+ " v.etiqueta, "
			+ " v.state, "
			+ " m.ruta as modulos "
			+ " FROM "
			+ " vistas v"
			+ " INNER JOIN modulos m ON m.id = v.modulos_id", nativeQuery = true)
Page<IVistasDTO> getDatatable(Pageable pageable, String search);

@Query(value = "SELECT "
	+ " count(Codigo) as quantity "
	+ " FROM "
	+ " vistas "
	+ " WHERE Codigo = :Codigo "
	+ " OR ruta = :ruta ", nativeQuery = true)
Optional<IVistasDTO> getValidate(String Codigo, String ruta);
}
