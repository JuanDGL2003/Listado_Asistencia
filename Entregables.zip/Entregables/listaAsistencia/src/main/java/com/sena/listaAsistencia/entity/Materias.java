
package com.sena.listaAsistencia.entity;

import java.util.Date;

import com.sena.listaAsistencia.seguridad.Entity.BaseModel;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "materias")
public class Materias extends BaseModel {

	@Column(name = "nombre_materia", nullable = false, length = 45)
	@Schema(description = "Nombre de la materia", required = true, maxLength = 45)
	private String nombreMateria;
	
	@Column(name = "descripcion", nullable = false, length = 50)
	@Schema(description = "Descripción del rol")
	private String descripcion;
	
	@Column(name = "horario", nullable = false, length = 50)
	@Schema(description = "Horario de las materias")
	private Date horario;

	public String getNombreMateria() {
		return nombreMateria;
	}

	public void setNombreMateria(String nombreMateria) {
		this.nombreMateria = nombreMateria;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getHorario() {
		return horario;
	}

	public void setHorario(Date horario) {
		this.horario = horario;
	}
	
	
}
