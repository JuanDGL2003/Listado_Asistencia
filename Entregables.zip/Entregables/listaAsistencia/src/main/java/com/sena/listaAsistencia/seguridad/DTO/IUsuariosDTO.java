package com.sena.listaAsistencia.seguridad.DTO;

import com.sena.listaAsistencia.seguridad.Entity.BaseModel.StateEnum;;

/**
 * Interfaz que define los métodos para acceder a los atributos de un objeto UserDto.
 */
public interface IUsuariosDTO {

	/**
     * Obtiene el estado del usuario.
     *
     * @return el estado del usuario
     */
	StateEnum getState();

    /**
     * Obtiene el nombre de usuario.
     *
     * @return el nombre de usuario
     */
    String getUsuario();

    /**
     * Obtiene la contraseña del usuario.
     *
     * @return la contraseña del usuario
     */
    String getContraseña();
}
