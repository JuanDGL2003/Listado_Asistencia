package com.sena.listaAsistencia.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.IRepositorio.IAsistenciasRepositorio;
import com.sena.listaAsistencia.IServicio.IAsistenciasServicio;
import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.entity.Asistencias;


@Service
public class AsistenciasServicio implements IAsistenciasServicio{

	@Autowired
	private IAsistenciasRepositorio repositorio;

	@Override
	public List<Asistencias> all() throws Exception{
		return repositorio.findAll();
	}
	
	@Override
	public Optional<Asistencias> findById(Integer id) throws Exception{
        Optional<Asistencias> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}
	
	@Override
	public Asistencias save(Asistencias asistencias) throws Exception{
		return repositorio.save(asistencias);
	}
	
	 @Override
	    public void update(Integer id, Asistencias asistencias) throws Exception {
	    	Optional<Asistencias> optionalAsistencias = this.repositorio.findById(id);

	        if (optionalAsistencias.isEmpty()) {
	            throw new Exception("No se encontró registro");
	        }

	        Asistencias asistenciasToUpdate = optionalAsistencias.get();
	        BeanUtils.copyProperties(asistencias, asistenciasToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

	        this.repositorio.save(asistenciasToUpdate);
	    }
	 @Override
	 public void delete(Integer id) throws Exception{
		 Optional<Asistencias> op = repositorio.findById(id);
	        if (op.isEmpty()) {
	            throw new Exception("No se encontró registro");
	        }
	        repositorio.deleteById(id);		
	}
}
