package com.sena.listaAsistencia.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.IRepositorio.IMateriasRepositorio;
import com.sena.listaAsistencia.IServicio.IMateriasServicio;
import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.entity.Materias;

@Service
public class MateriasServicio implements IMateriasServicio{

	@Autowired
	private IMateriasRepositorio repositorio;

	@Override
	public List<Materias> all() throws Exception{
		return repositorio.findAll();
	}
	
	@Override
	public Optional<Materias> findById(Integer id) throws Exception{
        Optional<Materias> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}
	
	@Override
	public Materias save(Materias materias) throws Exception{
		return repositorio.save(materias);
	}
	
	 @Override
	    public void update(Integer id, Materias materias) throws Exception {
	    	Optional<Materias> optionalMaterias = this.repositorio.findById(id);

	        if (optionalMaterias.isEmpty()) {
	            throw new Exception("No se encontró registro");
	        }

	        Materias materiasToUpdate = optionalMaterias.get();
	        BeanUtils.copyProperties(materias, materiasToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

	        this.repositorio.save(materiasToUpdate);
	    }
	 @Override
	 public void delete(Integer id) throws Exception{
		 Optional<Materias> op = repositorio.findById(id);
	        if (op.isEmpty()) {
	            throw new Exception("No se encontró registro");
	        }
	        repositorio.deleteById(id);		
	}
}
