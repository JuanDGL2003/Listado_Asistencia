package com.sena.listaAsistencia.seguridad.Entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Table;

@Entity
@Table(name = "roles")
public class Roles extends BaseModel{
	
	@Column(name = "codigo", nullable = false, unique = true, length = 10)
	@Schema(description = "Código del rol")
	private String codigo;

	@Column(name = "descripcion", nullable = false, length = 50)
	@Schema(description = "Descripción del rol")
	private String descripcion;
	

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
