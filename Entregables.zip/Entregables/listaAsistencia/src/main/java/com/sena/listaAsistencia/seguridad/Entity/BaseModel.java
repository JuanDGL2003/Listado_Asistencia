package com.sena.listaAsistencia.seguridad.Entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public class BaseModel {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Schema(description = "ID del registro")
    private int id;

	@Column (name = "state", nullable = false)
	@Schema(description = "Estado del registro")
	private StateEnum state;

	
	/**
	 * Retorna el ID del registro.
	 *
	 * @return el ID del registro
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Establece el ID del registro.
	 *
	 * @param id el ID del registro a establecer
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Retorna el estado del registro.
	 *
	 * @return el estado del registro
	 */
	public StateEnum getState() {
		return state;
	}

	
	/**
	 * Establece el estado del registro.
	 *
	 * @param state el estado del registro a establecer
	*/
	public void setState(StateEnum state) {
		this.state = state;
	}

	public enum StateEnum{
		Activo("true"), Inactivo("false");

		private final String codigo;

		StateEnum(String codigo) {
			this.codigo = codigo;
		}

		public String getCodigo() {
			return codigo;
		}

		public static StateEnum fromCode(String codigo) {
			for (StateEnum state : StateEnum.values()) {
				if (state.getCodigo().equalsIgnoreCase(codigo)) {
					return state;
				}
			}
			return null;
		}
	}
}
