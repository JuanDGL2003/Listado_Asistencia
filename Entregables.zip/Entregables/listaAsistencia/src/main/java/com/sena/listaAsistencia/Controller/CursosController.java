package com.sena.listaAsistencia.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sena.listaAsistencia.DTO.ApiResponseDto;
import com.sena.listaAsistencia.IServicio.ICursosServicio;
import com.sena.listaAsistencia.entity.Cursos;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/listaAsistencia/cursos")
public class CursosController {

	@Autowired
	private ICursosServicio service;

    @Operation(summary = "Obtener todas los cursos", responses = {
            @ApiResponse(responseCode = "200", description = "Lista de curso obtenida"),
            @ApiResponse(responseCode = "404", description = "No se encontraron curso")
    })
	
    @GetMapping
	public List<Cursos> all() throws Exception{
		return service.all();
	}

    @Operation(summary = "Obtener un curso por ID", responses = {
            @ApiResponse(responseCode = "200", description = "curso encontrado"),
            @ApiResponse(responseCode = "404", description = "curso no encontrado")
    })
    
    @GetMapping("{id}")
	public Optional<Cursos> show(@PathVariable Integer id) throws Exception{
		return service.findById(id);
	}

    @Operation(summary = "Crear un nuevo curso", responses = {
            @ApiResponse(responseCode = "201", description = "curso creado")
    })

	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public Cursos save(@RequestBody Cursos cursos) throws Exception{
		return service.save(cursos);
	}
    
    @Operation(summary = "Actualizar un curso existente", responses = {
            @ApiResponse(responseCode = "200", description = "curso actualizado"),
            @ApiResponse(responseCode = "404", description = "curso no encontrado")
    })
    
	@PutMapping("{id}")
	@ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<ApiResponseDto<Cursos>> update(@PathVariable Integer id, @RequestBody Cursos cursos) {
        try {
            service.update(id, cursos);
            return ResponseEntity.ok(new ApiResponseDto<Cursos>("Datos actualizados", null, true));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(new ApiResponseDto<Cursos>(e.getMessage(), null, false));
        }
    }
    
    @Operation(summary = "Eliminar un curso existente", responses = {
            @ApiResponse(responseCode = "204", description = "curso eliminado"),
            @ApiResponse(responseCode = "404", description = "curso no encontrado")
    })
    
	@DeleteMapping("{id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Integer id) throws Exception{
		service.delete(id);
	}
}
