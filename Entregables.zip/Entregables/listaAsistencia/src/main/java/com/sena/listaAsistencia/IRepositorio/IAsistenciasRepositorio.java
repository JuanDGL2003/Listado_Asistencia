package com.sena.listaAsistencia.IRepositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.listaAsistencia.entity.Asistencias;

public interface IAsistenciasRepositorio extends JpaRepository<Asistencias, Integer> {

}
