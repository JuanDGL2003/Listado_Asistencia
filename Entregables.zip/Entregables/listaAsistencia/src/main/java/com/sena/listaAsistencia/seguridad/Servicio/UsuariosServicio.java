package com.sena.listaAsistencia.seguridad.Servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.sena.listaAsistencia.Utils.GlobalConstants;
import com.sena.listaAsistencia.seguridad.DTO.ILoginDTO;
import com.sena.listaAsistencia.seguridad.DTO.IPermissionDTO;
import com.sena.listaAsistencia.seguridad.DTO.IUsuariosDTO;
import com.sena.listaAsistencia.seguridad.Entity.Usuarios;
import com.sena.listaAsistencia.seguridad.IRepositorio.IUsuariosRepositorio;
import com.sena.listaAsistencia.seguridad.IServicio.IUsuariosServicio;

@Service
public class UsuariosServicio implements IUsuariosServicio {

	@Autowired
	private IUsuariosRepositorio repositorio;

	@Override
	public List<Usuarios> all() throws Exception{
		return repositorio.findAll();
	}

	@Override
	public Optional<Usuarios> findById(Integer id) throws Exception{
        Optional<Usuarios> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        return op;
	}

	@Override
	public Usuarios save(Usuarios usuario) throws Exception{
		return repositorio.save(usuario);
	}
	
    @Override
    public void update(Integer id, Usuarios usuario) throws Exception {
    	Optional<Usuarios> optionalUsuarios = this.repositorio.findById(id);

        if (optionalUsuarios.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        Usuarios usuariosToUpdate = optionalUsuarios.get();
        BeanUtils.copyProperties(usuario, usuariosToUpdate, GlobalConstants.EXCLUDED_FIELDS.toArray(new String[0]));

        this.repositorio.save(usuariosToUpdate);
    }
	
	@Override
	public void delete(Integer id) throws Exception{
        Optional<Usuarios> op = repositorio.findById(id);

        if (op.isEmpty()) {
            throw new Exception("No se encontró registro");
        }

        repositorio.deleteById(id);		
	}
	
    @Override
	public Page<IUsuariosDTO> getDatatable(Pageable pageable, String search) throws Exception{
		return repositorio.getDatatable(pageable, search);
	}
    
    @Override
    public List<IPermissionDTO> getPermission(String usuario, String contraseña) throws Exception {
        return repositorio.getPermission(usuario, contraseña);
    }
    @Override
    public Optional<ILoginDTO> getLogin(String usuario, String contraseña) throws Exception {
        return repositorio.getLogin(usuario, contraseña);
    }

}
