package com.sena.listaAsistencia.seguridad.Entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "usuarios")
public class Usuarios extends BaseModel{
	
	@Column(name = "primer_nombre", nullable = false, length = 45)
	@Schema(description = "Primer nombre de la persona", required = true, maxLength = 45)
	private String primerNombre;

	@Column(name = "segundo_nombre", nullable = true, length = 45)
	@Schema(description = "Segundo nombre de la persona", required = true, maxLength = 45)	
	private String segundoNombre;

	@Column(name = "apellido", nullable = false, length = 45)
	@Schema(description = "Primer apellido de la persona", required = true, maxLength = 45)
	private String apellido;

	@Column(name = "segundo_apellido", nullable = true, length = 45)
	@Schema(description = "Segundo apellido de la persona", required = true, maxLength = 45)
	private String segundoApellido;
	
	@Column(name = "documento", nullable = false, length = 12, unique = true)
	@Schema(description = "Número de documento de la persona", required = true, maxLength = 12) 
	private String documento;
	
	@Column(name = "usuario", nullable = false, unique = true, length = 45)
	@Schema(description = "Nombre Usuario", required = true, maxLength = 12)
	private String usuario;

	@Column(name = "contraseña", nullable = false, unique = true, length = 45)
	@Schema(description = "Contraseña Usuario", required = true, maxLength = 12)
	private String contraseña;
	
	@Column(name = "tipo_usuario", nullable = false, unique = true, length = 45)
	@Schema(description = "Tipo de Usuario", required = true, maxLength = 12)
	private String tipoUsuario;
		
	public String getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContraseña() {
		return contraseña;
	}
	
	public String getPrimerNombre() {
		return primerNombre;
	}

	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}

	public String getSegundoNombre() {
		return segundoNombre;
	}

	public void setSegundoNombre(String segundoNombre) {
		this.segundoNombre = segundoNombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getSegundoApellido() {
		return segundoApellido;
	}

	public void setSegundoApellido(String segundoApellido) {
		this.segundoApellido = segundoApellido;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public void setContraseña(String contraseña) {
		this.contraseña = contraseña;
	}



	public enum TipoDocumento {
		CC("CC"), TI("TI");

		private final String codigo;

		TipoDocumento(String codigo) {
			this.codigo = codigo;
		}

		public String getCodigo() {
			return codigo;
		}

		public static TipoDocumento fromCode(String codigo) {
			for (TipoDocumento tipoDocumento : TipoDocumento.values()) {
				if (tipoDocumento.getCodigo().equalsIgnoreCase(codigo)) {
					return tipoDocumento;
				}
			}
			return null;
		}
	}

	public enum TipoUsuario{
		Profesor("profesor"), Estudiante("estudiante");
		
		private final String codigo;
		
		TipoUsuario(String codigo){
			this.codigo = codigo;
		}
		
		public String getCodigo() {
			return codigo;
		}
	}
	
		public static TipoUsuario fromCode(String codigo) {
			for (TipoUsuario tipoUsuario : TipoUsuario.values() ) {
				if(tipoUsuario.getCodigo().equalsIgnoreCase(codigo)) {
				  return tipoUsuario;
				}	
			}
			return null;
		}
}
	

