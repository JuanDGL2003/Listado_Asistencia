package com.sena.listaAsistencia.seguridad.IServicio;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.sena.listaAsistencia.seguridad.DTO.IVistaRolesDTO;
import com.sena.listaAsistencia.seguridad.Entity.VistasRoles;

public interface IVistasRolesServicio {

	/**
     * Recupera todos los roles de vista existentes.
     *
     * @return una lista de objetos ViewRole que representan todos los roles de vista existentes
     */
	public List<VistasRoles> all() throws Exception;
    
	 /**
     * Recupera un rol de vista por su ID.
     *
     * @param id el ID del rol de vista a recuperar
     * @return el objeto ViewRole correspondiente al ID proporcionado, o un Optional vacío si no se encuentra ningún rol de vista con el ID proporcionado
     */
	public Optional<VistasRoles> findById(Integer id) throws Exception;
	  
	 /**
     * Guarda un rol de vista en la base de datos.
     *
     * @param viewRole el objeto ViewRole a guardar
     * @return el objeto ViewRole guardado en la base de datos
     */
	public VistasRoles save(VistasRoles vistasRoles) throws Exception;
	    
	/**
     * Actualiza un rol de vista existente en la base de datos.
     *
     * @param id el ID del rol de vista a actualizar
     * @param viewRole el objeto ViewRole con los datos actualizados
     * @return el objeto ViewRole actualizado
     */
    public void update(Integer id, VistasRoles vistasRoles) throws Exception;
	
	/**
     * Elimina un rol de vista existente de la base de datos.
     *
     * @param id el ID del rol de vista a eliminar
     */
    public void delete(Integer id) throws Exception;

    /**
     * Recupera una página de roles de vista que coincidan con una cadena de búsqueda.
     *
     * @param pageable información sobre la paginación
     * @param search la cadena de búsqueda para filtrar los roles de vista
     * @return una página de objetos ViewRole que representan los roles de vista encontrados
     */
    public Page<IVistaRolesDTO> getDatatable(Pageable pageable, String search) throws Exception; 
}
