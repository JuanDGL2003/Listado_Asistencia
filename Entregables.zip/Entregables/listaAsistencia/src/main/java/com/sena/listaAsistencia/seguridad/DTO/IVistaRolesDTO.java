package com.sena.listaAsistencia.seguridad.DTO;

public interface IVistaRolesDTO {

}
