package com.sena.listaAsistencia.entity;

import java.util.Date;

import com.sena.listaAsistencia.seguridad.Entity.BaseModel;
import com.sena.listaAsistencia.seguridad.Entity.Usuarios;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "cursos")
public class Cursos extends BaseModel {

	@Column(name = "nombre_curso", nullable = false, length = 45)
	@Schema(description = "Nombre del curso", required = true, maxLength = 45)
	private String nombreCurso;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_materia", nullable = false, unique = true)
	private Materias materias;
			
	@Column(name = "hora_inicio", nullable = false, length = 45)
	@Schema(description = "Incio de la clase ", required = true, maxLength = 45)
	private Date horaInicio;
			
	@Column(name = "hora_fin", nullable = false, length = 45)
	@Schema(description = "Fin de la clase", required = true, maxLength = 45)
	private Date horaFin;
			
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "id_usuario", nullable = false, unique = true)
	private Usuarios usuarios;
	
	public String getNombreCurso() {
		return nombreCurso;
	}
	
	public void setNombreCurso(String nombreCurso) {
	this.nombreCurso = nombreCurso;
	}
	
	public Materias getMaterias() {
		return materias;
	}
	public void setMaterias(Materias materias) {
		this.materias = materias;
	}
	
	public Date getHoraInicio() {
		return horaInicio;
	}
	
	public void setHoraInicio(Date horaInicio) {
	this.horaInicio = horaInicio;
	}
	
	public Date getHoraFin() {
		return horaFin;
	}
	
	public void setHoraFin(Date horaFin) {
	this.horaFin = horaFin;
	}
	
	public Usuarios getUsuarios() {
	return usuarios;
	}
	
	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}
}