package com.sena.listaAsistencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListaAsistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
